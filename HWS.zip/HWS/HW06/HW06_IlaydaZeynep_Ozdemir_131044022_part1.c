    /*##################################################################*/
    /*HW06_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Job Assignment                                                    */
    /*Inputs:                                                           */
    /*  -Random Job Energies                                            */
    /*Outputs:                                                          */
    /*  -Regulated job energy                                           */
    /*  -The best employeer of days and week                            */
    /*##################################################################*/
    
#include<stdio.h>
#include<string.h>
#define ENERGIES "Energies.txt"
#define REPORTS "Reports.txt"
#define NUM_EMPLOYEES 4
#define NUM_DAYS 7

typedef enum {Ali,Ayse,Fatma,Mehmet} employee;
typedef enum{Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday} day;


    /*------------------------------------------------------------------*/
    /*                           FUNCTIONS                              */
    /*------------------------------------------------------------------*/
    
void read_matrix(const char* file_name, int m[NUM_EMPLOYEES][NUM_DAYS]);
void create_work_plan(int job_schedule[NUM_EMPLOYEES][NUM_DAYS], int m[NUM_EMPLOYEES][NUM_DAYS]);
employee find_the_employer_of_the_day(int work_schedule[NUM_EMPLOYEES][NUM_DAYS], day day_name);
employee find_the_employer_of_the_week(int work_schedule[NUM_EMPLOYEES][NUM_DAYS]);
void report(const char* file_name, int job_scheduling[NUM_EMPLOYEES][NUM_DAYS]);
void sort(int array[],int size);
   
    /*------------------------------------------------------------------*/
    /*                           MAIN                                   */
    /*------------------------------------------------------------------*/
    
int main()
{
    int i,j;
    int job_energies[NUM_EMPLOYEES][NUM_DAYS];
    int job_schedule[NUM_EMPLOYEES][NUM_DAYS];
    int work_schedule[NUM_EMPLOYEES][NUM_DAYS];
    char i_file[20]="Energies.txt";
    char o_file[20]="Report.txt";
    employee who;
    employee week;

    read_matrix(i_file,job_energies);
    create_work_plan(job_schedule, job_energies);

    for(i=0;i<NUM_EMPLOYEES;++i)
    {
        for(j=0;j<NUM_DAYS;++j)
        {
        
        work_schedule[i][j]=job_schedule[i][j];    
        
        }
    }


    report(o_file,job_schedule);
return 0;
}

/*-----------------------------------------------------------------------*/
/*You have to read the energy of the jobs from the file “energies.txt”,  */
/*create the matrix job_energies[NUM_EMPLOYEES][NUM_DAYS] and fill it in.*/
/*-----------------------------------------------------------------------*/

void read_matrix(const char* file_name, int m[NUM_EMPLOYEES][NUM_DAYS])
{
    int i,j;
    FILE *in_ptr;
    if((in_ptr=fopen(file_name,"r"))==NULL)
        printf("ERROR!");


    for(i=0;i<NUM_DAYS;++i)/*satir*/
    {
        for(j=0;j<NUM_EMPLOYEES;++j)/*sutun*/
        {
            fscanf(in_ptr,"%d",&m[j][i]); /*& unutma!*/    
        }
      
    }
 
    fclose(in_ptr);
}

/*-----------------------------------------------------------------------*/
/*                      Do job assignment                                */
/*-----------------------------------------------------------------------*/
void create_work_plan(int job_schedule[NUM_EMPLOYEES][NUM_DAYS], int m[NUM_EMPLOYEES][NUM_DAYS])
{
    int i,j,sum=0,e=0,d=0;
    int temp[50];
    
    for(i=0;i<NUM_EMPLOYEES;++i)
    {
        for(j=0;j<NUM_DAYS;++j)
        {     
          job_schedule[i][j]=m[i][j];
        }

    }   /*num_emp satir oluyor*/

/*----------------------------------------------------------------------------*/
 
/*doldurulacak sutundan oncekileri toplayip,her satirin toplam degerini temp*/
/*arrayine attiktan sonra temp arrayi sort edilir*/
/*yeni gunun enerjileri sort edilecek*/   
/*en buyuk olana en az enerjili verilir*/
/*Ama ben bu sekilde yapamadim*/
/*Yorum satirindaki kisim sadece tum sutunlari en buyukten en kucuge siralar*/
/*      for(i=0;i<NUM_DAYS;++i)
        {
            for(j=0;j<NUM_EMPLOYEES;++j)
                temp[j]=job_schedule[j][i];

            sort(temp,NUM_EMPLOYEES);
            for(j=0;j<NUM_EMPLOYEES;++j)
                job_schedule[j][i]=temp[j];  
        }



/*-------------------------------------------------------------*/
}

void sort(int array[],int size) /*buyukten kucuge siraliyor*/
{
    int i,j,temp;
    int max_index;
    
    for(i=0;i<size-1;++i)
    {
        max_index=i;
        for(j=i+1;j<size;++j)
        {
            if(array[j]>array[max_index])
            max_index=j;
         
        }
        temp=array[i];
        array[i]=array[max_index];
        array[max_index]=temp;
    }
}
                /***************************************/
                /*Gunun en cok enerji harcayanini bulur*/
                /***************************************/
                
employee find_the_employer_of_the_day(int work_schedule[NUM_EMPLOYEES][NUM_DAYS], day day_name)
{
    int max,i;
    int temp[4];
    employee who;
    employee j;

    for(i=0;i<day_name+1;++i)
    {
        for(j=0;j<NUM_EMPLOYEES;++j)
        {  
            temp[j]=work_schedule[j][i];

        }

    sort(temp,NUM_EMPLOYEES);
    }      

      
     for(i=0;i<day_name+1;++i)
    {
        for(j=0;j<NUM_EMPLOYEES;++j)
        {  
            if(temp[0]==work_schedule[j][i])
                who=j; 
        }
    }  
   return who; 
}

                /******************************************/
                /*Haftanin en cok enerji harcayanini bulur*/
                /******************************************/
                
employee find_the_employer_of_the_week(int work_schedule[NUM_EMPLOYEES][NUM_DAYS])
{
    int i,j,sum=0;
    int temp[4];
    employee who;

    
     for(i=0;i<NUM_EMPLOYEES;++i)
    {
        sum=0;  
        for(j=0;j<NUM_DAYS;++j)
        {  
            sum+=work_schedule[i][j];
  
        }
        temp[i]=sum; 
    } 

   
   sort(temp,NUM_EMPLOYEES); 
   
     for(i=0;i<NUM_EMPLOYEES;++i)
    {
        sum=0;  
        for(j=0;j<NUM_DAYS;++j)
        {  
            sum+=work_schedule[i][j];
            if(temp[0]==sum)
               who=i;
        }
        
    }    
  
   /*temp[0] en buyuk toplam. Bu kime aitse o kisinin indexi donuyor*/
return who;  

}
                    /************************************/
                    /*Dosyaya yazdirma islemlerini yapar*/
                    /************************************/
                    
void report(const char* file_name, int job_scheduling[NUM_EMPLOYEES][NUM_DAYS])
{
    FILE *out_ptr;
    day days;
    employee week_who;
    employee who;
    int i,j,k; /*counters*/
    char *days_arr[]={"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    char *employees_arr[NUM_EMPLOYEES]={"Ali" , "Ayse" , "Fatma" , "Mehmet"};
    
    if((out_ptr=fopen(file_name,"w"))==NULL)
        printf("ERROR!!");;
   
    fprintf(out_ptr,"          "); /*tabloyu duzenlemek icin*/
    for(i=0;i<NUM_DAYS;++i)   
         fprintf(out_ptr,"%-10s",days_arr[i]);

    
    fprintf(out_ptr,"\n");  
    for(i=0;i<NUM_EMPLOYEES;++i)
    {
        fprintf(out_ptr,"%-10s",employees_arr[i]);  
        for(j=0;j<NUM_DAYS;++j)
        {
   
            fprintf(out_ptr,"%-10d",job_scheduling[j][i]);
        }
        
        fprintf(out_ptr,"\n");
    }
    fprintf(out_ptr,"\n");   
    for(i=0;i<NUM_DAYS;++i) 
    { 
        days=Monday;
        who=find_the_employer_of_the_day(job_scheduling,days+i);
        fprintf(out_ptr,"The best employer of %s %s \n",days_arr[i],employees_arr[who]);
        fprintf(out_ptr,"\n");
    }
    

    week_who=find_the_employer_of_the_week(job_scheduling);
    fprintf(out_ptr,"The best employer of week is %s .... Congratulations %s !!\n",employees_arr[week_who],employees_arr[week_who]);
}



    /*##################################################################*/
    /*    End of HW06_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c      */
    /*##################################################################*/

