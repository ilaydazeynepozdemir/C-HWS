    /*##################################################################*/
    /*HW06_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Job Assignment                                                    */
    /*Inputs:                                                           */
    /*  -Noun                                                           */
    /*  -Hard,Soft,Flat,Round vovels                                    */
    /*Outputs:                                                          */
    /*  -Plural Noun                                                    */
    /*                                                                  */
    /*##################################################################*/

#include<stdio.h>
#include<string.h>

#define NOUNS "Nouns.txt"
#define VOWELS "Vowels.txt"
#define PLURAL "Plural.txt"
typedef enum {FALSE,TRUE}bool;
typedef enum {HARD,SOFT,CONSONANT}major_type;
typedef enum {FLAT,ROUND,CONSONANT_2}minor_type;


    /*------------------------------------------------------------------*/
    /*                           FUNCTIONS                              */
    /*------------------------------------------------------------------*/

bool is_major_vh_word(const char* word, const char* v_hard, const char* v_soft);
major_type major(const char ch1, const char* v_hard, const char* v_soft);
bool is_minor_vh_word( const char* word, const char* v_flat, const char* v_round);
minor_type minor(const char ch1, const char* v_flat, const char* v_round);
major_type find_last_type(const char* word,const char* v_hard,const char* v_soft);
char* make_plural(const char* noun , char* plural_noun,const char* v_hard,const char* v_soft);

    /*------------------------------------------------------------------*/
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~MAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /*------------------------------------------------------------------*/
int
main()
{
    int status,x;
    char word[20];
    char v_hard[5],v_soft[5],v_flat[5],v_round[5];
    bool major_TF,minor_TF;
    char *plural_noun;
    
    
    FILE *in_nouns,*in_vowels,*out_plural;
    if((in_nouns=fopen(NOUNS,"r"))==NULL)
        printf("ERROR!");
    if((in_vowels=fopen(VOWELS,"r"))==NULL)
        printf("ERROR!!");
    if((out_plural=fopen(PLURAL,"w"))==NULL)
        printf("ERROR!!!");


        fscanf(in_vowels,"%s",v_hard);
        fscanf(in_vowels,"%s",v_soft);
        fscanf(in_vowels,"%s",v_flat);
        fscanf(in_vowels,"%s",v_round);
        
        printf("%13s%10s\n","MAJOR","MINOR");
        
    
    do{
        status=fscanf(in_nouns,"%s",word);
        if(status!=EOF)
        {
        printf("%-10s",word);
        
        major_TF=is_major_vh_word(word,v_hard,v_soft);
        switch (major_TF)
        {
            case TRUE:printf("%-10c",'T');break;
            case FALSE:printf("%-10c",'F');break;
        }     
        
        minor_TF=is_minor_vh_word(word,v_flat,v_round);
        switch (minor_TF)
        {
            case TRUE:printf("%-10c\n",'T');break;
            case FALSE:printf("%-10c\n",'F');break;
        }    
       
       make_plural(word,plural_noun,v_hard,v_soft);
       fprintf(out_plural,"%s\n",plural_noun);
       
       }
    }while(status!=EOF);

    fclose(in_nouns);
    fclose(in_vowels);
    fclose(out_plural);


return 0;
}

                /********************************/
                /*Buyuk unlu uyumunu kontroleder*/
                /********************************/

bool is_major_vh_word(const char* word, const char* v_hard, const char* v_soft)
{
    int i,j;
    char ch;
    bool flag=FALSE;
    major_type x;
    major_type temp=-1,temp1=-1;
    bool result;
 

        for(j=0;j<strlen(word);++j)
        {
             ch=word[j];

             x=major(ch,v_hard,v_soft);
             if(x==HARD)
                temp=x;
                
             if(x==SOFT)
                temp1=x;    
        } 
        
        if(temp==HARD && temp1==SOFT)
            result=FALSE;
        else if((temp=-1) || (temp1=-1))
            result=TRUE;
 return result;   
}

    /*************************************************************/
    /*karakterin kalin unlu mu ince unlu mu oldugunu kontrol eder*/
    /*************************************************************/
                               
major_type major(const char ch1, const char* v_hard, const char* v_soft)
{
    major_type result=CONSONANT;
    int a;    
        
        for(a=0;a<4;++a)
        {

            if(ch1==v_hard[a])
             {   
                result=HARD;
             }
           
        }
        
        for(a=0;a<4;++a)
        {
            if(ch1==v_soft[a])
            {   
                result=SOFT;
            } 
             
        }
    return result;
}

    /*************************************************************/
    /*karakterin dar unlu mu genis unlu mu oldugunu kontrol eder*/
    /*************************************************************/
minor_type minor(const char ch1, const char* v_flat, const char* v_round)
{
    major_type result=CONSONANT_2;
    int a;    
        
        for(a=0;a<4;++a)
        {

            if(ch1==v_flat[a])
             {   
                result=FLAT;
             }
           
        }
        
        for(a=0;a<4;++a)
        {
            if(ch1==v_round[a])
            {   
                result=ROUND;
            } 
             
        }
        return result;
}
        
        
        /*************************************************************/
        /*      kucuk unlu uyumuna uyup uymadigini kontrol eder      */
        /*************************************************************/

bool is_minor_vh_word( const char* word, const char* v_flat, const char* v_round)
{
    int i,j;
    char ch;
    bool flag=FALSE;
    major_type x;
    major_type temp=-1,temp1=-1;
    bool result;
 

        for(j=0;j<strlen(word);++j)
        {
             ch=word[j];

             x=minor(ch,v_flat,v_round);
             if(x==FLAT)
                temp=x;
                
             if(x==ROUND)
                temp1=x;    
       
        }
        
    if(temp==FLAT && temp1==ROUND)
        result=FALSE;
    else if((temp=-1) || (temp1=-1))
        result=TRUE;
    return result;   

}

/********************************************************************************/
/*kelimenin son hecesindeki unluyu kontrol eder.Kalin unlu mu ince unlu mu diye.*/
/********************************************************************************/

major_type find_last_type(const char* word,const char* v_hard,const char* v_soft)
{
    int i;    
    int last;
    major_type res=CONSONANT;
    last=strlen(word)-1;
    for(i=0;i<4;++i)
    {
        if(word[last]==v_hard[i])
            res=HARD;
        else if(word[last]==v_soft[i])
            res=SOFT;
    }  
    
    for(i=0;i<4;++i)
    {
        if(word[last-1]==v_hard[i])
            res=HARD;
        else if(word[last-1]==v_soft[i])
            res=SOFT;
    } 
    
           
    return res;
}

/***********************************************************************************/ 
/*           kelimeleri son hecesindeki sesliye bakarak cogul yapar                */
/*     maine yolladigimda dosyaya yazdiramadim.Ama fonksiyon kendi icinde yaziyor  */
/***********************************************************************************/
    
char* make_plural(const char* noun , char* plural_noun,const char* v_hard,const char* v_soft)
{
    int i,a;
    major_type x;
    char temp[50];
    char plural1[10]="lar";
    char plural2[10]="ler";

    x=find_last_type(noun,v_hard,v_soft);
    
    for(i=0;i<=strlen(noun);++i)
        temp[i]=noun[i];

    switch(x)
    {
        case HARD:plural_noun=strcat(temp,plural1);break;
        case SOFT:plural_noun=strcat(temp,plural2);break;
    
    }
return plural_noun;
/*printf("-%s -",plural_noun);*/

}



    /*##################################################################*/
    /*    End of HW06_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c      */
    /*##################################################################*/
