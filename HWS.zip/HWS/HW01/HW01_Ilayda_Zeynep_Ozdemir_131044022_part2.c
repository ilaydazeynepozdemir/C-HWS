    /*##################################################################*/
    /*HW01_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Calculate x,y and f(x,y)                                          */
    /*Inputs:                                                           */
    /*  -Coefficients of equations and function                         */
    /*  -Result of equation                                             */
    /*Outputs:                                                          */
    /*  -Resulting function f(x,y)                                      */
    /*##################################################################*/
    /*                                                                  */
    /*------------------------------------------------------------------*/
    /*                     Includes                                     */
    /*------------------------------------------------------------------*/


#include <stdio.h>

                    /* function definition */

double function(double x,double y); 


    /*------------------------------------------------------------------*/
    /*                      main function                               */
    /*------------------------------------------------------------------*/

int main(void)
{

            /* Equations are a1x + b1y = r1 and a2x + b2y = r2 */

    double x,
           y,
           coef_a1,/*coefficient of x in first equation*/
           coef_a2,/*coefficient of xin second equation*/
           coef_b1,/*coefficient of y in first equation*/
           coef_b2,/*coefficient of y in second equation*/
           res_r1, /*result of first equation*/
           res_r2, /*result of second equation*/
           func;   /*To call function*/
                            
                           /*create file*/ 
    FILE *optr,  
         *iptr1,
         *iptr2;
         
    optr=fopen ("Results2.txt","w");        /* open file to write value */
    iptr1=fopen ("EqCoefficients.txt","r"); /*open file to take coefficient of equations*/

    fscanf(iptr1,"%lf %lf %lf %lf %lf %lf",&coef_a1, &coef_b1, &res_r1, &coef_a2, &coef_b2,&res_r2);
    
    x=(coef_b1*res_r2-res_r1*coef_b2) / (coef_b1*coef_a2 - coef_b2*coef_a1); /*value of x*/
    y=(res_r1 - coef_a1*x) / coef_b1;              /*value of y*/
    
    func=function(x,y);                        /* Call function(x,y) */
       
    fprintf(optr,"%.0f %.0f %.0f",x,y,func); /* print at file of outputs */
    
    printf("\nValue of x= %.0f \nValue of y= %.0f \n\n",x,y);
    printf("\nResult of f(%.0f,%.0f)= %.0f \n\n",x,y,func);
   
    fclose(iptr1); /*close file*/

    fclose(optr); /*close file*/
    return 0;
}

    /*------------------------------------------------------------------*/
    /*                      function f(x,y)                             */
    /*------------------------------------------------------------------*/

       /*Take a coefficients of function and Calculate function*/

double function(double x,double y)
{
    double coef1,    /*coefficien of x in function */
           coef2,   /*coefficient of y in function*/
           result; /*result of function*/       
    FILE *inp;    /*create*/
         
    inp=fopen("FuncCoefficients.txt","r");          /*open file*/
    
    fscanf(inp,"%lf %lf",&coef1,&coef2);/*take coefficient of function at text file*/
    
    result=coef1*x + coef2*y;                   /*calculate function*/
      
    fclose (inp);                                  /*close file*/

    return result;
        
             /* I did writing in file at main function */
}
    /*##################################################################*/
    /*    End of HW01_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c      */
    /*##################################################################*/
