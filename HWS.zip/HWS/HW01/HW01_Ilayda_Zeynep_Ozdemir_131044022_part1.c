    /*##################################################################*/
    /*HW01_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Calculate g(f(x)) and f(g(x))                                     */
    /*Inputs:                                                           */
    /*  -Value of x                                                     */
    /*Outputs:                                                          */
    /*  -g(f(x)) and f(g(x))                                            */
    /*##################################################################*/
    /*                                                                  */
    /*------------------------------------------------------------------*/
    /*                    Includes and defines                          */
    /*------------------------------------------------------------------*/


#include<stdio.h>
#include<math.h>   /*mathematic libary*/
#define Y 8.0      /*Y is constant macro*/

            /*they are constant macros in functions*/

#define THREE 3.0   
#define TWO 2.0
#define ONE 1.0
#define TWO_HALF 2.5

                 /* function definition */

double function_gof (int x);
double function_fog (int x);

    /*------------------------------------------------------------------*/
    /*                      main function                               */
    /*------------------------------------------------------------------*/


int main (void)

{

    int x;  
    double fog,             /* f(g(x)) */
           gof;             /* g(f(x)) */
           
                            /*create files*/   
    FILE *optr, 
         *iptr;
         
         
    iptr=fopen("Variables.txt","r");  /*open input file*/
    optr=fopen("Results1.txt","w");   /*open output file*/
    
    fscanf(iptr,"%d",&x);             /*take value of x at input file*/
    
    gof=function_gof(x);              /*call function gof*/
    
    fog=function_fog(x);              /*call function fog*/
    
    
    /*print console*/
    printf("\nResult of g(f(%d))=%f \n",x,gof);
    printf("\nResult of f(g(%d))=%f \n\n",x,fog);
    
    fprintf(optr,"%f %f ",gof,fog);  /*print at output file*/

    fclose(iptr);                    /*close input file*/
    fclose(optr);                    /*close output file*/
    
    return 0;

}



    /*------------------------------------------------------------------*/
    /*                      g(f(x)) function                            */
    /*------------------------------------------------------------------*/


                /*this function calculate g(f(x)) */

double function_gof (int x)

{
    double result_gof,     /*result of g(f(x))*/
           fx;          /*result of f(x) function*/
    
                      /*calculate f(x) and result_gof*/
                                
    fx= sin( pow( (x+Y)/x + sqrt(log(pow (THREE,x) / (TWO*x+ONE))), TWO_HALF)) ;
    
    result_gof=fx+(ONE/(fx+Y/(TWO*fx)));
   
    return result_gof;
}



    /*------------------------------------------------------------------*/
    /*                     f(g(x)) function                             */
    /*------------------------------------------------------------------*/


                    /*this function calculate f(g(x)) */

double function_fog (int x)
{
    double result_fog,     /*result of f(g(X))*/
           gx;          /*result of g(x) function*/    
    
                    /*calculate g(x) and result_fog*/
    
    gx=x+(ONE/(x+Y/(TWO*x)));
    
    result_fog=sin(pow((gx+Y)/gx + sqrt(log(pow(THREE,gx) / (TWO*gx+ONE))),TWO_HALF));
    
    return result_fog;
} 
    /*##################################################################*/
    /*    End of HW01_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c      */
    /*##################################################################*/


