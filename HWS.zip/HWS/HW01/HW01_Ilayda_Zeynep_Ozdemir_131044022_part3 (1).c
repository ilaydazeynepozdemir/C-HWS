    /*##################################################################*/
    /*HW00_<IlaydaZeynep>_<Ozdemir>_<131044022>_part3.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Calculate total fuel cost for car                                 */
    /*Inputs:                                                           */
    /*  -identification numbers of cars                                 */
    /*  -price of fuel,amount of fuel,total km                          */
    /*Outputs:                                                          */
    /*  -total fuel cost                                                */
    /*##################################################################*/
    /*                                                                  */
    /*------------------------------------------------------------------*/
    /*              Includes and defines                                */
    /*------------------------------------------------------------------*/


#include <stdio.h>
#define ADD_REMOVE 100  /*this is 0.50 transform to 50 or 50 tranform 0.50*/
                                         /*Add 0 Remove 0*/

                    /* function definition */

int calculate_tl ( double price,double amount_fuel,double total_km );
double calculate_kr ( double price,double amount_fuel,double total_km );

    /*------------------------------------------------------------------*/
    /*                      main function                               */
    /*------------------------------------------------------------------*/


int main (void)
{
    int car_number, /*identification number of cars*/
        car_tl;     /*call function which calculate tl*/
           
    double car_kr,      /*call function which calculate kr*/
           price,       /*price of fuel*/
           amount_fuel, /*amount (lt) of fuel consumed per km*/
           total_km,    /*total km taken by car*/
           fr_txt;      /*calculate total tl+kr for text file */
 
    FILE * optr,        /*create files*/
         * iptr;
         
    iptr = fopen("Cars.txt","r");           /*open input file*/
    optr = fopen("TotalFuelCosts.txt","w"); /*open output file*/

   
                                
                                /*intended informations for car1*/
    
    fscanf(iptr,"%d %lf %lf %lf",&car_number,&amount_fuel,&price,&total_km); /*take value at input file*/  
    
    car_tl=calculate_tl ( price, amount_fuel, total_km); 
    car_kr=calculate_kr ( price, amount_fuel, total_km);  
    
                                        /*print console*/
    printf("\nThe total fuel cost of the car %d is %d TL and %.0f Kurus \n",car_number,car_tl,car_kr);   
    
    fr_txt=(car_tl + (car_kr / ADD_REMOVE));            /*this sum and divide for result*/
    fprintf(optr,"  %d    %5.2f\n",car_number,fr_txt); /*write at output file*/


 
                              /*intended informations for car2*/
    
    fscanf(iptr,"%d %lf %lf %lf",&car_number,&amount_fuel,&price,&total_km); /*take value at input file*/     
    
    car_tl=calculate_tl ( price, amount_fuel, total_km);
    car_kr=calculate_kr ( price, amount_fuel, total_km);
    
                                    /*print console*/
    printf("\nThe total fuel cost of the car %d is %d TL and %.0f Kurus \n",car_number,car_tl,car_kr);
    
    fr_txt=(car_tl + (car_kr / ADD_REMOVE));            /*this sum and divide for result*/
    fprintf(optr,"  %d    %5.2f\n",car_number,fr_txt); /*write at output file*/
  

                                
                             /*intended informations for car3*/
    
    fscanf(iptr,"%d %lf %lf %lf",&car_number,&amount_fuel,&price,&total_km);  /*take value at input file*/    
    
    car_tl=calculate_tl ( price, amount_fuel, total_km);
    car_kr=calculate_kr ( price, amount_fuel, total_km);
    
                                  /*print console*/
    printf("\nThe total fuel cost of the car %d is %d TL and %.0f Kurus \n\n",car_number,car_tl,car_kr);
    
    fr_txt=(car_tl + (car_kr / ADD_REMOVE) );           /*this sum and divide for result*/
    fprintf(optr,"  %d    %5.2f\n",car_number,fr_txt); /*write at output file*/
 
    fclose(iptr); /*close input file*/
    fclose(optr); /*close output file*/
       
    return (0);

}

    /*------------------------------------------------------------------*/
    /*                    calculating tl function                       */
    /*------------------------------------------------------------------*/

                   /*function to calculate total tl*/
int calculate_tl ( double price,double amount_fuel,double total_km )
{
    int tl;
    
    tl=(price*amount_fuel*total_km);
    
    return tl;
}


    /*------------------------------------------------------------------*/
    /*                    calculating kr function                       */
    /*------------------------------------------------------------------*/



               /*function to calculate total kr*/
double calculate_kr ( double price,double amount_fuel,double total_km )
{
    int tl1;
    double kr;
    
    tl1=(price * amount_fuel * total_km); /*this part to make integer value at calculate kr*/
    kr=( (price*amount_fuel*total_km) - tl1) * ADD_REMOVE; 
  
    return kr;
}


    /*##################################################################*/
    /*    End of HW01_<IlaydaZeynep>_<Ozdemir>_<131044022>_part3.c      */
    /*##################################################################*/
