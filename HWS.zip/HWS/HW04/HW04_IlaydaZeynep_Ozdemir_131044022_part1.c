/*************************************************************
 *                                                           *
 * HW04 Q1                                                   *
 * Student Name: Ilayda Zeynep Ozdemir                       *
 * Student ID  : 131044022                                   *
 * Date        : 10-17 March 2015                            *
 * Points      : 27                                          *
 *                                                           *
 *************************************************************/


#include <stdio.h>

#define ZERO 0

#define PLAINTEXTFILE "Files/Q1/PlainMessagesToSent.txt"
#define ENCODEDFILE "Files/Q1/EncodedMessages.txt"
#define CRYPTEDFILE "Files/Q1/CryptedMessages.txt"
#define M 5

/*************************************************************
 * Gets FILE* to write file and character to encode          *
 * uses encoding table to convert plain text to              *
 * encoded message                                           *
 *************************************************************/

void 
encode_and_write_to_file(FILE *f_out_ptr, char character);

/*************************************************************
 * Gets FILE* f_in_ptr to read from plain text file and      *
 * FILE* f_out_ptr to write message to encoded file          *
 * return number of characters read from plain text          *
 *************************************************************/

int 
encode_message(FILE *f_in_ptr, FILE *f_out_ptr);


/*************************************************************
 * Gets FILE* f_in_ptr to read from encoded text file and    *
 * FILE* f_out_ptr to write message to encrypted file        *
 * return encoded character number                           *
 *************************************************************/

int 
crypt_message(FILE *f_in_ptr, FILE *f_out_ptr);

/*************************************************************/
/*                      MAIN                                 */
/*************************************************************/

int 
main(int argc, char* argv[])
{

	
	
	FILE *f_plane_ptr, *f_encoded_ptr, *f_crypted_ptr;

    f_plane_ptr=fopen(PLAINTEXTFILE,"r");
    f_encoded_ptr=fopen(ENCODEDFILE,"w");   /*mode of write.because that is output file*/  
    if (f_plane_ptr==NULL || f_encoded_ptr==NULL)
        printf("File is not open");
    else 
    {
    encode_message(f_plane_ptr, f_encoded_ptr);    
  
    fclose(f_encoded_ptr);
    fclose(f_plane_ptr); 
    }

    
    f_crypted_ptr=fopen(CRYPTEDFILE,"w");
    f_encoded_ptr=fopen(ENCODEDFILE,"r");   /*mode of read.because that is input file*/
    if (f_crypted_ptr==NULL || f_encoded_ptr==NULL)
            printf("File is not open");
    else
    {
	crypt_message(f_encoded_ptr, f_crypted_ptr);
	fclose(f_encoded_ptr);
    fclose(f_crypted_ptr);
    }
    
	return 0;
}

/*****************************************/
/*  this function defines encoding table */
/*****************************************/

void 
encode_and_write_to_file(FILE *f_out_ptr, char character)
{

int i; /*counter*/

 
    switch (character) /* it select for each letter*/
    {
        case 'E':   /*counter start 16.So it enter the loop for once*/
            i=16;      
            break;   
        
        case 'I':
            i=15;
            break;
            
        case ' ':
            i=14;
            break;
 
        case 'T':
            i=13;
            break;
      
        case 'C':
            i=12;
            break;
   
        case 'N':
            i=11;
            break;
         
        case 'A':
            i=10;
            break;
       
        case 'G':
            i=9;
            break;
          
        case 'B':
            i=8;
            break;
   
        case 'Z':
            i=7;
            break;
  
        case 'H':
            i=6;
           break;     
            
        case 'L':
            i=5;
            break; 
            
        case 'U':
            i=4;
            break; 
               
        case 'V':
            i=3;
            break; 

        case 'R':
            i=2;
            break; 
  
        case 'S':
            i=1;
            break; 
     
        case 'Y':
            i=0;
            break; 
        
        case '\n':
            break;
        
        default: 
            fprintf(f_out_ptr,"%c",character);
    }	
    
     for(i ; i<16 ; i++)
    {	
        fprintf(f_out_ptr,"1");
    }
    
    
    
    fprintf(f_out_ptr,"0");  

}


/****************************************************************/
/*  this function encode message according to encoding table    */
/****************************************************************/

int 
encode_message(FILE *f_in_ptr, FILE *f_out_ptr)
{
    int counter = ZERO;
	char character;
	int status;

/*f_in_ptr = f_plane_ptr*/
/*f_out_ptr = f_encoded_ptr*/

	status=fscanf(f_in_ptr,"%c",&character);
	
	while(status != EOF) /*read end of file*/ 
	{	
	
	    if(status!=EOF)
	    {
            encode_and_write_to_file(f_out_ptr,character);
        }
        
        ++counter;                                 /*counter of character*/
        status=fscanf(f_in_ptr,"%c",&character);  /*update*/
    }

	return counter;
}

/*******************************************************/
/*This function crypt the message and write output file*/
/*******************************************************/



int 
crypt_message(FILE *f_in_ptr, FILE *f_out_ptr)
{

    int counter = ZERO;
	char number;
	int status;
	int i=ZERO;
	int N=ZERO;      /*To reduce to count.*/
	int count=ZERO; /* to keep for character number*/


/*f_in_ptr =  f_encoded_ptr*/
/*f_out_ptr = f_crypted_ptr*/

	
    status=fscanf(f_in_ptr,"%c",&number);  

	
	while(status != EOF) /*read end of file*/ 
	{

        if (number=='0')
        {
            fprintf(f_out_ptr,"_");
            ++count;  /* to keep for character number*/
        }
        
        else if (number=='1')
        {
            fprintf(f_out_ptr,"*");
            ++count;    /* to keep for character number*/
        }
        

        
        if ( count == M-N)  /*M=5 . It is constant macro*/
                          /*If I do if(count == M), after each 5 character printed - */ 
                          /******************when it is M-N , N crease **************************/
        {
            fprintf(f_out_ptr,"-");
            
            count=ZERO;
            ++N; /**/
            
            if(N==M) /**/
                N=ZERO;
        }
        
        counter++;                              /*counter of character*/
        status=fscanf(f_in_ptr,"%c",&number);  /*update*/
    }
	


	return counter;
}
