#include <stdio.h>

#define PLAINTEXTFILE "Files/Q2/ReceivedMessage.txt"
#define ENCODEDFILE "Files/Q2/EncodedInput.txt"
#define CRYPTEDINPUT "Files/Q2/CryptedInput.txt"

/*void 
decode_and_write_to_file(FILE *f_out_ptr, int number_of_ones);

int 
decode_message(FILE *f_in_ptr, FILE *f_out_ptr);*/

int 
decrypt_message(FILE *f_in_ptr, FILE *f_out_ptr);

int 
main(int argc, char* argv[])
{

	FILE *f_plane_ptr, *f_encoded_ptr, *f_crypted_ptr;


    f_crypted_ptr=fopen(CRYPTEDINPUT,"r");
    f_encoded_ptr=fopen(ENCODEDFILE,"w");   /*write mode because of output file*/
    
    if (f_crypted_ptr==NULL  || f_encoded_ptr==NULL)
        printf("File is not open");
    else
    { 
        decrypt_message(f_crypted_ptr, f_encoded_ptr);    
    
        fclose(f_encoded_ptr);
        fclose(f_crypted_ptr);
    }


    f_plane_ptr=fopen(PLAINTEXTFILE,"w");
    f_encoded_ptr=fopen(ENCODEDFILE,"r");   /*write mode because of output file*/
    if (f_plane_ptr==NULL || f_encoded_ptr==NULL)
        printf("File is not open");
    else 
    {
	  /*  decode_message(f_encoded_ptr, f_plane_ptr);	*/
	    fclose(f_encoded_ptr);
	    fclose(f_plane_ptr);
    }




	return 0;
}



int 
decrypt_message(FILE *f_in_ptr, FILE *f_out_ptr)
{
 
 
 
 /*f_in_ptr=f_crypted_ptr*/
/*f_out_ptr= f_encoded_ptr*/
   
    char char_code;
    int status;
    int i=0;
    
    status=fscanf(f_in_ptr,"%c",&char_code);
    
    while(status != EOF)
    {
    switch (char_code)
    {
        case '*':  /*  *  */
            fprintf(f_out_ptr,"1");
            
            break;
        
        case'_':   /* _   */
            fprintf(f_out_ptr,"0");
            break;
            
        case'-':   /*-*/
            break;
    }
    
    ++i;
    status=fscanf(f_in_ptr,"%c",&char_code);
    }
}
