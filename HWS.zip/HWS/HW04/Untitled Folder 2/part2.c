    /*##################################################################*/
    /*HW05_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Find array's value                                                */
    /*Inputs:                                                           */
    /*  -n                                                              */
    /*  -value                                                          */
    /*Outputs:                                                          */
    /*  -maximum of array                                               */
    /*  -second maximum of array                                        */
    /*  -sum all of array                                               */  
    /*  -count of value in array                                        */  
    /*  -search value in array                                          */
    /*##################################################################*/
    
#include<stdio.h>
#define ARRAY_SIZE 8
#define LINE_LENGTH 30

typedef enum {TRUE=1,FALSE=0}bool;

    /*------------------------------------------------------------------*/
    /*                           FUNCTIONS                              */
    /*------------------------------------------------------------------*/
    
int max_array(const int myarray[], int n);
int second_max_array(const int myarray[], int n);
int sum_all_array (const int myarray[], int n);
int count_array(const int myarray[], int n, int value);
bool search_array (int myarray[], int n, int value);
void draw_line(void);

    /*------------------------------------------------------------------*/
    /*                           MAIN                                   */
    /*------------------------------------------------------------------*/

int
main(void)
{
    int n=ARRAY_SIZE;
    int myarray[]={6,8,3,3,12,8,3,8,2};
    
    bool search;    /*******************/  
    int max,        /*                 */
        sec_max,    /*To call functions*/
        count,      /*                 */
        sum;        /*******************/



    draw_line();

    max=max_array(myarray, n);
    printf("Maximum array is %d\n",max);
    draw_line();
    
    sec_max=second_max_array(myarray,n);
    printf("Maximum second array is %d\n",sec_max); 
    draw_line();
    
    sum=sum_all_array (myarray, n);
    printf("Sum of all array is %d\n",sum); 
    draw_line();
    
    count=count_array(myarray,n,8);
    printf("Count of value 8 is %d\n",count); 
    
    count=count_array(myarray,n,3);
    printf("Count of value 3 is %d\n",count); 
    
    count=count_array(myarray,n,12);
    printf("Count of value 12 is %d\n",count);  
    draw_line();
   
    search=search_array (myarray, n, 2);
    if(search==FALSE)
        printf("This value is not include in array\n");
    
    search=search_array (myarray, n, 8);
    if(search==FALSE)
        printf("This value is not include in array\n");
        
    search=search_array (myarray, n, 12);
    if(search==FALSE)
        printf("This value is not include in array\n");
    
    draw_line();
        
    return 0;

}

/***********************/
/*Returns maximum value*/
/***********************/

int 
max_array(const int array[], int n)
{
    int i;/*to process the array elements.Actually i is counter for loop*/
    int max_arr;
    
    max_arr=array[0];  /*to make comparisons between the value*/

    for(i=0 ; i<=n ; ++i)
    {   
        if(max_arr <= array[i]) 
            max_arr=array[i];
    }
    
    return max_arr;
}



/******************************/
/*Returns second maximum value*/
/******************************/
int 
second_max_array(const int myarray[], int n)
{

    int third_max,
        second_max, 
        i=0,a=0,b=1;

/*------------------------------------------------*/
/*We make a comparison between the number of all  */
/*we find second max and third max                */
/*------------------------------------------------*/    
    second_max=myarray[a]; 
    third_max=myarray[b];   
       
       do
       {
        
        if(second_max==max_array(myarray,n)) /*To ignore first max value of array*/
            second_max=0;
       
        if(third_max > second_max && third_max!=max_array(myarray,n)) /*To ignore first max value of array*/
        {
            second_max=third_max;
        }  
       ++b;
       third_max=myarray[b];

       }while(b<=n);

    return second_max;
}



/**************************/
/*Returns sum of all array*/
/**************************/
int 
sum_all_array (int const array[], int n)
{
    int i=0,/*to process the array elements.Actually i is counter for loop*/
        sum=0;
        
    for(i=0 ; i<=n ; ++i)
        sum+=array[i];
    
    return sum;

}



/**************************/
/*Returns count of a value*/
/**************************/
int 
count_array(int const array[], int n, int value)
{
    int i=0,/*to process the array elements.Actually i is counter for loop*/
        count=0;
   
    while(i<=n)
    {
        while(array[i]==value)
        {   
            count+=1;
            ++i;
            array[i];
        }
    ++i;
    }
  
   return count ;
}



/***********************************/
/*Prints location of searched value*/
/***********************************/
bool 
search_array (int array[], int n, int value)
{
    int keep_i=0,/*To keep the value of i*/
        i=0;/*to process the array elements.Actually i is counter for loop*/
    
    for(i=0 ; i<=n  ; ++i)
    {
        if(array[i]!=value)
        {
            ++i;
            if(i>=n)
                return FALSE; /*if value is not include in array*/     
        }
        
        if(array[i]==value)
        {   
            keep_i=i;
            i=n;
            printf("%d is at [%d]\n",value,keep_i);
            return TRUE;
        }
        
        
           
     }
}


/****************************************/
/*To draw line to seperate output values*/
/****************************************/
void 
draw_line(void)
{
    int line;
    for(line=0 ; line<LINE_LENGTH ;++line)
        printf("-");

    printf("\n");

}

    /*##################################################################*/
    /*    End of HW05_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c      */
    /*##################################################################*/
