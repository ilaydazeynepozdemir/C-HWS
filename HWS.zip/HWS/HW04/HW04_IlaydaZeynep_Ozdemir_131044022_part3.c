/*************************************************************
 *                                                           *
 * HW04 Q3                                                   *
 * Student Name: Ilayda Zeynep Ozdemir                       *
 * Student ID  : 131044022                                   *
 * Date        : 10-17 March 2015                            *
 * Points      : 20                                          *
 *                                                           *
 *************************************************************/
#include <stdio.h>

#define TRUE 1
#define FALSE 0
#define CHARACTERFILE "Files/Q3/CharacterList.txt"
#define SAMPLEFILE "Files/Q3/Sample.txt"
#define ENCODEDFILE "Files/Q3/XUniversityEncoded.txt"
#define PLAINTEXTFILE "Files/Q3/XUniversityMessage.txt"

/*************************************************************
 * Swaps values of two integers                              *
 *************************************************************/
void 
swap_int(int *a, int *b);

/*************************************************************
 * Swaps values of two characters                            *
 *************************************************************/
void 
swap_char(char *a, char *b);

/*************************************************************
 * Sorts characters according to counts. At the end          *
 * make sure that *c1 keeps most frequent used letter, *c3   *
 * keeps least frequent used letter and *c2 keeps remained   *
 * letter                                                    *
 *************************************************************/
void
sort(char *a, int a_num, char *b, int b_num, char *c, int c_num);

/*************************************************************
 * Check whether character is big ASCII letter or not        *
 * return TRUE or FALSE                                      *
 *************************************************************/
int 
is_letter(char c);

/*************************************************************
 * Read characters from character list file and if character *
 * is letter assign characters to c1, c2 and c3.             *
 * If file has not three letters assign NULL to input char   *
 * by order. For ex. file has two letters assign proper      *
 * letters to c1 and c2 and assign NULL to c3. If file has   *
 * four letters assign c1, c2 and c3 first three letters.    *
 * Return number of letters in character list file.          *
 * Do not forget to count only proper letters with your      *
 * is_letter function. Return number of letters not chars    *
 *************************************************************/
int 
read_character_list(FILE* f_in_ptr, char *c1, char *c2, char *c3);

/*************************************************************
 * Read letters from Sample file and compute frequency of    *
 * letters. Then sort it inside this function. Call sort     *
 * function. At the end make sure that *c1 keeps most        *
 * frequent used letter, *c3 keeps least frequent used       *
 * letter and *c2 keeps remained letter                      *
 *************************************************************/
void 
count_letters(FILE *f_in_ptr, char *c1, char *c2, char *c3);

/*************************************************************
 * Read from XUniversityEncoded file to decode message and   *
 * write decoded (plain text) message to XUniversityMessage  *
 * file. Make sure c1 keeps most frequent used letter,  c3   *
 * keeps least frequent used letter and  c2 keeps remained   *
 * letter while calling function. According to frequency     *
 * you know their codes. c1: 0, c2: 10, c3: 110.             *
 *************************************************************/
void 
decode(FILE *f_in_ptr, FILE *f_out_ptr, char c1, char c2, char c3);

/*************************************************************
 * Learns XUniversity's encoding system from given files ,   *
 * decodes their encoded messages and writes as plain text to*
 * a file                                                    *
 *************************************************************/


/*************************************************************/
/*                      MAIN                                 */
/*************************************************************/

int 
main(int argc, char* argv[])
{
	FILE *f_character_list_ptr, *f_sample_file_ptr, *f_encoded_ptr,
		*f_plain_text_ptr;
	int character_number;
	char c1, c2, c3;
	
	f_character_list_ptr=fopen(CHARACTERFILE,"r") ;
	f_sample_file_ptr=fopen(SAMPLEFILE,"r");
	f_encoded_ptr=fopen(ENCODEDFILE,"r");
	f_plain_text_ptr=fopen(PLAINTEXTFILE,"w");

	
	/* exit program and print error if character list file could not be opened to read */
	if (f_character_list_ptr==NULL)
    {
        printf("File is not open 1\n");
        return 0;
    }
    else
    { 

        read_character_list(f_character_list_ptr,&c1, &c2, &c3);    
        fclose(f_character_list_ptr);
	/* call read_character_list function and get return value *
	 * if number of letter read is not equal to three exit    *
	 * program                                                */
    }



	/* exit program and print error if sample file could not be opened to read */
	if (f_sample_file_ptr==NULL)
    {
        printf("File is not open 2\n");
        return 0;
    }
    else
    { 
    /* Call count_letters function and swap letters inside function *
	 * according to number of counts                                */	
        count_letters(f_sample_file_ptr, &c1, &c2, &c3);  
	    fclose(f_sample_file_ptr);
	
	/* close sample file */
    }
	

	/* exit program and print error if plain text file could not be opened to write */
	/* exit program and print error if encoded file could not be opened to read */
	if (f_encoded_ptr==NULL || f_plain_text_ptr==NULL)
    {
        printf("File is not open 3\n");
        return 0;
    }
    else
    { 
        
        decode(f_encoded_ptr,f_plain_text_ptr, c1, c2, c3);  
	    
	    fclose(f_plain_text_ptr);   
	    fclose(f_encoded_ptr);
	 
	 /* Call decode function */	
    /* close encoded and plain text file */
	 

    }

	return 0;
}

/*************************************************************
 * Swaps values of two integers                              *
 *************************************************************/
void 
swap_int(int *a, int *b)
{
    int temp;
    temp= *a;
    *a = *b;
    *b = temp;
}

/*************************************************************
 * Swaps values of two characters                            *
 *************************************************************/
void 
swap_char(char *a, char *b)
{
    char temp;
    temp= *a;
    *a = *b;
    *b = temp;
}

/*************************************************************
 * Sorts characters according to counts. At the end          *
 * make sure that *c1 keeps most frequent used letter, *c3   *
 * keeps least frequent used letter and *c2 keeps remained   *
 * letter                                                    *
 *************************************************************/
void
sort(char *a, int a_num, char *b, int b_num, char *c, int c_num)
{

    
   if(a_num>b_num)
        swap_char(a,b);
   else if (b_num>c_num)
        swap_char(b,c);
   else if(a_num>c_num)
        swap_char(a,c);
        


	
}

/*************************************************************
 * Check whether character is big ASCII letter or not        *
 * return TRUE or FALSE                                      *
 *************************************************************/
int 
is_letter(char c)
{
	int value;
	
	value = 'c';    

	if(value >= 65 && value <= 90) /*grade letter return TRUE else return FALSE*/
	    return TRUE;

	else  
	    return FALSE;
	
	
	/* Hint: Look for difference with 'A' to understand 
	 * character is a big letter or not. Use ASCII codes to
	 * determine if it is a big letter or not          
	 */
	 
	 

}

/*************************************************************
 * Read characters from character list file and if character *
 * is letter assign characters to c1, c2 and c3.             *
 * If file has not three letters assign NULL to input char   *
 * by order. For ex. file has two letters assign proper      *
 * letters to c1 and c2 and assign NULL to c3. If file has   *
 * four letters assign c1, c2 and c3 first three letters.    *
 * Return number of letters in character list file.          *
 * Do not forget to count only proper letters with your      *
 * is_letter function. Return number of letters not chars    *
 *************************************************************/
int 
read_character_list(FILE* f_in_ptr, char *c1, char *c2, char *c3)
{	
	int counter = 0;
	char char_;
	int status;
	int call_is_letter;
	
	status=fscanf(f_in_ptr,"%c",&char_);
	
	    while (is_letter(char_)==FALSE && status != EOF)
	    {
	        status=fscanf(f_in_ptr,"%c",&char_);
	        
           if(status==EOF)
            *c1='\0';   	
	    }
	    *c1=char_;
	    counter+=1;
	    
        while (is_letter(char_)==FALSE && status != EOF)
	    {
	        status=fscanf(f_in_ptr,"%c",&char_); 
	        
           if(status==EOF)
            *c2='\0';  
	    }

	    *c2=char_;
	    counter+=1;
        
        while (is_letter(char_)==FALSE && status != EOF)
	    {
	        status=fscanf(f_in_ptr,"%c",&char_); 
	        
           if(status==EOF)
            *c3='\0';  
	    }

	    *c3=char_;
	    counter+=1;

        
        while (status != EOF)
        {
            if(is_letter(char_)==TRUE)
            {
            ++counter;
            }
        status=fscanf(f_in_ptr,"%c",&char_);
        }


	return counter;
}

/*************************************************************
 * Read letters from Sample file and compute frequency of    *
 * letters. Then sort it inside this function. Call sort     *
 * function. At the end make sure that *c1 keeps most        *
 * frequent used letter, *c3 keeps least frequent used       *
 * letter and *c2 keeps remained letter                      *
 *************************************************************/
void 
count_letters(FILE *f_in_ptr, char *c1, char *c2, char *c3)
{

    char char_;
    int status;
    int count_c1=0,count_c2=0,count_c3=0;
    char temp1,temp2,temp3;
    
    status=fscanf(f_in_ptr,"%c",&char_);
    
    while(status != EOF)
    {
      
      *c1=char_;
      status=fscanf(f_in_ptr,"%c",&char_); 
      ++count_c1;
       
      
      if(char_ != *c1) 
      {  *c2=char_; 
        ++count_c2;
      }
      
        
      status=fscanf(f_in_ptr,"%c",&char_);  
      
      if(char_!=*c2 && char_!=*c1)
      {  *c3=char_;
        ++count_c3;
      }
        
     sort(c1, count_c1, c2, count_c2, c3, count_c3);
     
    /*printf("%c %c %c \n",*c1,*c2,*c3);
     printf("count_c1=%d \ncount_c2=%d \ncount_c3=%d\n",count_c1,count_c2,count_c3);*/

     status=fscanf(f_in_ptr,"%c",&char_);   
    }

	/* Hint: Read character by character and increment counter
	 * of proper counter of read character.
	 */

	/*
	 *
	 Some magic here
	 *
	 */

}

/*************************************************************
 * Read from XUniversityEncoded file to decode message and   *
 * write decoded (plain text) message to XUniversityMessage  *
 * file. Make sure c1 keeps most frequent used letter,  c3   *
 * keeps least frequent used letter and  c2 keeps remained   *
 * letter while calling function. According to frequency     *
 * you know their codes. c1: 0, c2: 10, c3: 110.             *
 *************************************************************/


void 
decode(FILE *f_in_ptr, FILE *f_out_ptr, char c1, char c2, char c3)
{
	char ch_1_0;
	int status;
	int i;
	
	status=fscanf(f_in_ptr,"%c",&ch_1_0);
 /* printf("%c",ch_1_0); */
	
	while(status!=EOF)
	{
	
        if(ch_1_0 != '0')
        {
            ++i;
        }
        
        else 
            i=0;
            
            if(i==0)
                fprintf(f_out_ptr,"%c",c1);
            else if(i==1)
                fprintf(f_out_ptr,"%c",c2);
            else if(i==2)
                fprintf(f_out_ptr,"%c",c3);
        

	status=fscanf(f_in_ptr,"%c",&ch_1_0);
	}

                    /*	printf ("%c",c1);
	                    printf ("%c",c2);
	                    printf ("%c",c3);  */
	/* Hint: While reading from encoded text file keep reading 
	 *		 character by character. Use ASCII difference from 0
	 *		 to determine number is 0 or 1. If we try reading it
	 *		 as integer, it overflows. Overflow is bad if you are 
	 *		 not hacker and do not want to crash system deliberately.
	 */

	/*
	 *
	 Some magic here
	 *
	 */

}
