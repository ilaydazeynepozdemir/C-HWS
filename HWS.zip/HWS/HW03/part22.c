#include <stdio.h>
/* sayılar 1.0 gibi YAZ!!!!!!!! */


int calculate_grade(int exam_1,int exam_2,int f_exam);
int calculate_contribution ();

int main (void)
{

    FILE *optr;
    
    int call1,
        mid_1,
        mid_2,
        final;
    double call2;
    
    char grade,
        initial_name,
         initial_sname;

    
    optr=fopen("Grade.txt","w");
    
    call2=calculate_contribution ();
    call1=calculate_grade(mid_1,mid_2,final);

    fprintf(optr,"%c %c %d %c %.3f",initial_name,initial_sname,call1,grade,call2);
   
  


    call2=calculate_contribution ();
    call1=calculate_grade(mid_1,mid_2,final);

    fprintf(optr,"%c %c %d %c %.3f",initial_name,initial_sname,call1,grade,call2);
    
    fclose(optr);


    return 0;

}

int calculate_grade(int exam_1,int exam_2,int f_exam)
{
    int result;    
    result=(exam_1*30.0)/100 + (exam_2*30)/100 + (f_exam*40)/100;
    return result;
}


int calculate_contribution()
{

    double contribution;

    int call,grade;
    int mid_1,mid_2,final;
    
    char initial_name,
         initial_sname;


    FILE *iptr;   
         
    iptr=fopen("Students.txt","r");

    
    fscanf(iptr,"%c %c %d %d %d ",&initial_name,&initial_sname,&mid_1,&mid_2,&final);
    
    fscanf(iptr,"%c %c %d %d %d ",&initial_name,&initial_sname,&mid_1,&mid_2,&final);
    
    call=calculate_grade(mid_1,mid_2,final);
    
    if ( call >= 85 && call <= 100) 
      grade='A'; 
    else if (call >= 70 && call <= 84)
       grade='B'; 
    else if (call >= 65 && call <= 69)
       grade='C'; 
    else if (call >=40 && call <=64)
       grade='D';
    else if (call <= 39)
       grade='F';         
       
                  
   
    switch (grade)
    {
        
        case 'A': 
                  printf("grade %c and %d\n",grade,call);
                  contribution=4.0*3.0/20;
                  printf("contribution=%.3f \n",contribution);
        break;
        
        case 'B': 
                  printf("grade %c and %d\n",grade,call);
                  contribution=3.0*3.0/20;
                  printf("contribution=%.3f \n",contribution);
        break;
        
        case 'C': 
                  printf("grade %c and %d\n",grade,call);
                  contribution=2.0*3.0/20; 
                  printf("contribution=%.3f \n",contribution);
        break;
        
        case 'D': 
                printf("grade %c and %d\n",grade,call);
                contribution=(1.0*3.0)/20;
                printf("contribution=%.3f \n",contribution);
        break;
        
        case 'F':
                  printf("grade %c and %d\n",grade,call);
                  contribution=0;
                  printf("contribution=%.3f \n",contribution);
        break;
        
        default: printf("Gecerli not gir");
        
    }
    

    fclose(iptr);

    return contribution;

}
