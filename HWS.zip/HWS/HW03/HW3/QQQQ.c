    /*##################################################################*/
    /*HW02_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Guessing An Integer Number                                        */
    /*Inputs:                                                           */
    /*  -Guess number                                                   */
    /*Outputs:                                                          */
    /*  -Warn or Congratulation message                                 */
    /*##################################################################*/
 
#include<stdio.h>
#include<stdlib.h>
#define ZERO 0
#define ONE 1
#define TWO 2
#define THREE 3
#define FIVE 5
#define TEN 10

    /*------------------------------------------------------------------*/
    /*                           FUNCTIONS                              */
    /*------------------------------------------------------------------*/

int RNG ();                                         /*To generate the random number*/
int CalculateTheDifference(int num_1,int num_2);    /*To calculate the difference between guess and the number*/
int WarnThePlayer(int num_1,int num_2);             /*To print a warning in order to guide the player*/
int play(int guess,int number,int i);

    /*------------------------------------------------------------------*/
    /*                           MAIN                                   */
    /*------------------------------------------------------------------*/
int 
main (void)

{
    int guess,i,          /*parameter of function.Take from player*/
        number;         /*parameter of function.RNG function generate*/
        
    char dec;
           
     
    printf("Enter the P to play guess game.If you exit the game,enter E. 111\n");
    
    scanf("%c",&dec);
   
   
   
    
    while (dec=='P')
{
    
    printf("Enter the number as a guess (From 1 to 10) > ");
    
    scanf("%d",&guess);   /*First guess number*/
    number=RNG();

    WarnThePlayer(guess,number);
           
  /*If player does not know number,he/she has second chance*/
 
   
 
   for(i=2;guess<number || guess>number;++i) 
{
        printf("Try again!!! Enter the number as a guess (From 1 to 10) > ");

        scanf("%d",&guess); 
        
        WarnThePlayer(guess,number);
}
    
    
    
    while (CalculateTheDifference(guess,number)==ZERO) 
{
    printf("Enter the P to play guess game.If you exit the game,enter E. 2222\n");
    scanf("%c",&dec);
    
    
    switch (dec)
{   
    case 'P':
    play(guess,number,i);
    break;
    
    case 'E':
    return 0;
    break;
   
    default :
        printf("Please enter P or E (uppercase letter is not important)\n");
}
    
    
}
    
}    
    
    while (dec=='E')
    {
    return 0;
    }
        

return 0;


}

    /*------------------------------------------------------------------*/
    /*        This function To generate the random number               */
    /*------------------------------------------------------------------*/

int RNG(){

    int number1;
    srand(time(NULL));
    number1=(rand()%TEN)+ONE;
    return number1;

}

   /*----------------------------------------------------------------------*/
   /*This function calculate difference between input number random number */
   /*----------------------------------------------------------------------*/

int CalculateTheDifference(int num1,int num2)
{
    int result, /*difference num1 and num2*/
        temp;  /*temprature value*/

/*To change of value if num2>num1 */ 
    if (num2>num1)
    {
    temp=num2;
    num2=num1;
    num1=temp;
    }
/*-------------------------------*/
  
    result=num1 - num2;

    return result;
}

    /*------------------------------------------------------------------*/
    /*                      This function warns player                  */
    /*------------------------------------------------------------------*/

int WarnThePlayer (int num_1,int num_2)
{
    int difference; /*To call difference function*/
    
    difference=CalculateTheDifference (num_1,num_2);

        /*----------------------------------*/
        /*          If statement            */
        /*----------------------------------*/
  
    if(difference == ZERO)
        printf("<<<Congratulation for winning>>>\n");
    else if (difference >= FIVE)
        printf("You are too far from the number\n");
    else if (difference >= THREE)
        printf("You are far from the number\n");
    else if (difference <= TWO)
        printf("You are close to the number\n");

return difference;

}



int play(int guess,int number,int i)
{


printf("Enter the number as a guess (From 1 to 10) > ");
    
scanf("%d",&guess);   /*First guess number*/
number=RNG();

WarnThePlayer(guess,number); 
 
for(i=2;guess<number || guess>number;++i) 
{

    printf("Try again!!! Enter the number as a guess (From 1 to 10) > ");
    scanf("%d",&guess); 
    WarnThePlayer(guess,number);

}

}




    /*##################################################################*/
    /*    End of HW02_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c      */
    /*##################################################################*/


