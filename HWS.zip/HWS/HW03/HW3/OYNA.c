    /*##################################################################*/
    /*HW02_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Guessing An Integer Number                                        */
    /*Inputs:                                                           */
    /*  -Guess number                                                   */
    /*Outputs:                                                          */
    /*  -Warn or Congratulation message                                 */
    /*##################################################################*/
 
#include<stdio.h>
#include<stdlib.h>
#define ZERO 0
#define ONE 1
#define TWO 2
#define THREE 3
#define FIVE 5
#define TEN 10

    /*------------------------------------------------------------------*/
    /*                           FUNCTIONS                              */
    /*------------------------------------------------------------------*/

int RNG ();                                         /*To generate the random number*/
int calculate_the_difference(int num_1,int num_2);    /*To calculate the difference between guess and the number*/
int warn_the_player(int num_1,int num_2,int i);             /*To print a warning in order to guide the player*/
int play(int num1_1,int num1_2,int i);

    /*------------------------------------------------------------------*/
    /*                           MAIN                                   */
    /*------------------------------------------------------------------*/
int 
main (void)

{
    int guess,
        i=ONE,
        dif,          /*parameter of function.Take from player*/
        number;         /*parameter of function.RNG function generate*/
        
    char dec;
           
     
    printf("Enter the P to play guess game.If you exit the game,enter E. 111\n");
    
    scanf("%c",&dec);
  
    while (dec=='P')
    {
        
        printf("Enter the number as a guess (From 1 to 10) > ");
        
        scanf("%d",&guess);   
        
        number=RNG();
        
        printf("Random=%d\n",number);
        
       /* warn_the_player(guess,number,i);*/
        guess = play(guess,number,i); /* To play game */
        
        dif=calculate_the_difference(guess,number) ;
       
        printf("Random=%d\n",number);
       
        while (dif==ZERO) 
        {
        printf("Enter the P to play guess game.If you exit the game,enter E. 2222\n");
        scanf(" %c",&dec);
        
        
            switch (dec)
            {   
                case 'P':
               
                    printf("Enter the number as a guess (From 1 to 10) > ");
                    scanf("%d",&guess);   
                    number=RNG();
                    play(guess,number,i);
               
                break;
                
                case 'E':
                    return 0;
                break;
               
                default :
                    printf("Please enter P or E (uppercase letter is not important)\n");
            }
        
        
        }
    
}    
    
    while (dec=='E')
    {
        return 0;
    }
        

    return 0;


}

    /*------------------------------------------------------------------*/
    /*        This function To generate the random number               */
    /*------------------------------------------------------------------*/

int RNG()
{

    int number1;
    srand(time(NULL));
    number1=(rand()%TEN)+ONE;
 /*   printf("%d\n",number1); */
    return number1;

}

   /*----------------------------------------------------------------------*/
   /*This function calculate difference between input number random number */
   /*----------------------------------------------------------------------*/

int calculate_the_difference(int num1,int num2)
{
    int result, /*difference num1 and num2*/
        temp;  /*temprature value*/

/*To change of value if num2>num1 */ 
    if (num2>num1)
    {
    temp=num2;
    num2=num1;
    num1=temp;
    }
/*-------------------------------*/
  
    result=num1 - num2;

    return result;
}

    /*------------------------------------------------------------------*/
    /*                      This function warns player                  */
    /*------------------------------------------------------------------*/

int warn_the_player (int num_1,int num_2,int i)
{
    int difference; /*To call difference function*/
    
    difference=calculate_the_difference (num_1,num_2);
    
     /*   printf("%d\n",num_2); */

        /*----------------------------------*/
        /*          If statement            */
        /*----------------------------------*/
  
    if(difference == ZERO)
    {
        printf("\n<<<Congratulation for winning>>>\n");
        printf("     >>>%d.guess is true<<<\n\n",i);
    }
    else if (difference >= FIVE)
        printf("You are too far from the number\n");
    else if (difference >= THREE)
        printf("You are far from the number\n");
    else if (difference <= TWO)
        printf("You are close to the number\n");

    return difference;

}



int play(int num1_1,int num1_2,int i)
{
    if(warn_the_player(num1_1,num1_2,i) != ZERO)
    { 
 
 
 /* Counter start from 2.Because process do before enter the loop */
 
        for(i=2 ; num1_1 != num1_2 ; ++i) 
        {

            printf("Try again!!! Enter the number as a guess (From 1 to 10) > ");
            scanf("%d",&num1_1); 
            warn_the_player(num1_1,num1_2,i);

        }    
    
    }
    
    return num1_1;    

}




    /*##################################################################*/
    /*    End of HW02_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c      */
    /*##################################################################*/


