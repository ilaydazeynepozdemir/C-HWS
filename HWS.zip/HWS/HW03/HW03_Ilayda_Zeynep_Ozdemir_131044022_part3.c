    /*##################################################################*/
    /*HW03_<IlaydaZeynep>_<Ozdemir>_<131044022>_part3.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Bounce of ball                                                    */
    /*Inputs:                                                           */
    /*  -number                                                         */
    /*Outputs:                                                          */
    /*  -figure of rebounce                                             */
    /*##################################################################*/


#include<stdio.h>
#define ZERO 0
#define ONE 1
#define TWO 2
#define THREE 3


    /*------------------------------------------------------------------*/
    /*                           FUNCTIONS                              */
    /*------------------------------------------------------------------*/

int draw_diag_step(int height,int feet_height,char the_peak_point,char the_road_point);
int finish_diag(int length,int first_height,int feet_height);  
int draw_hor_diag_of_bb (int first_height,int feet_height,char the_peak_point,char the_road_point);


    /*------------------------------------------------------------------*/
    /*                           MAIN                                   */
    /*------------------------------------------------------------------*/


int main (void)
{
int first_height,feet_height,length;
char the_peak_point,the_road_point;


/*first call*/
draw_hor_diag_of_bb (5,4,'O','*');
finish_diag(length,5,4);


/*second call*/
draw_hor_diag_of_bb (6,2,'O','*');
finish_diag(length,6,2);


/*three call*/
draw_hor_diag_of_bb (3,3,'O','*');
finish_diag(length,3,3);

}

/*--------------------------------*/
/*this function to draw the figure*/
/*--------------------------------*/

int draw_diag_step(int height,int feet_height,char the_peak_point,char the_road_point)
{
int column,row,i;   
int total=ZERO;

/*The up part of the figure*/
    for(row=ZERO ; row < (TWO*height+ONE) / TWO ; row++)
    {
    
        for(i=ONE ; i <= row*feet_height; i++)
        {
        printf(" ");
        }
        
        for (column=ONE ; column <= feet_height ; column++)
        {
            printf("%c",the_road_point);
            total+=ONE;
        }
    
        printf("\n");
    }

/*the peak point of figure*/    
    for(column=ONE ; column <= height*feet_height ; column++)
    {
        printf(" ");

    }   
    
    printf("%c",the_peak_point);
    total+=ONE;
    printf("\n");     

    
    
/*The down part of the figure*/    
    for(row=((TWO*height+ONE)/TWO)-ONE ; row >= ZERO ; row--)
    {
    
        for(i=ONE ; i <= row*feet_height; i++)
        {
            printf(" ");
        }
        
        for (column=ONE ; column <= feet_height ; column++)
        {
            printf("%c",the_road_point);
            total+=ONE;
        }
    
        printf("\n");
    }


return total;

}

/*---------------------------*/
/*length of the symbolic form*/
/*---------------------------*/

/*I do not understand return value in this function*/
int finish_diag(int length,int first_height,int feet_height)
{

int count=ZERO,a=ZERO;

    length = (first_height*feet_height)+ONE ;
    for(count=ZERO; count <= length ; count++)
        {
            printf("-");
        }

    printf(">\n\n");

}


/*-----------------------------------------*/
/*this function to draw reducing the height*/
/*-----------------------------------------*/


int draw_hor_diag_of_bb (int first_height,int feet_height,char the_peak_point,char the_road_point)
{
int bounce_height=ZERO,result_func,total_for_char=ZERO;

    for(bounce_height=first_height ; bounce_height>=ONE ; bounce_height--)
    {

    result_func=draw_diag_step(bounce_height,feet_height,the_peak_point,the_road_point);

    total_for_char+=result_func;

    }

    printf("%d\n",total_for_char);
}


    /*##################################################################*/
    /*    End of HW03_<IlaydaZeynep>_<Ozdemir>_<131044022>_part3.c      */
    /*##################################################################*/

