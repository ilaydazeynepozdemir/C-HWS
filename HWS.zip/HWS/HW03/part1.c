    /*##################################################################*/
    /*HW02_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Guessing An Integer Number                                        */
    /*Inputs:                                                           */
    /*  -Guess number                                                   */
    /*Outputs:                                                          */
    /*  -Warn or Congratulation message                                 */
    /*##################################################################*/
 
#include<stdio.h>
#include<stdlib.h>
#define ZERO 0
#define ONE 1
#define TWO 2
#define THREE 3
#define FIVE 5
#define TEN 10

    /*------------------------------------------------------------------*/
    /*                           FUNCTIONS                              */
    /*------------------------------------------------------------------*/

int RNG ();                                         /*To generate the random number*/
int calculate_the_difference(int num_1,int num_2);    /*To calculate the difference between guess and the number*/
int warn_the_player(int num_1,int num_2,int i);             /*To print a warning in order to guide the player*/
int cong_win(int num1_1,int num1_2,int i);
int call(int guess,int number,int i);
char dec;


    /*------------------------------------------------------------------*/
    /*                           MAIN                                   */
    /*------------------------------------------------------------------*/
int 
main (void)

{

    int a,b,c,dif;
    char dec;
    
    printf("Enter the P to play guess game.If you exit the game,enter E.\n");
    scanf("%c",&dec);
    
    dif=calculate_the_difference(a,b);
    
    while (dec=='P')
    {




    printf("Enter the number as a guess (From 1 to 10) > ");
            
    scanf("%d",&a);   /*First guess number*/
    b=RNG();
            
    warn_the_player(a,b,c);   
    
    for(c=2;a<b || a>b;++c) 
        { 
 
        printf("Try again!!! Enter the number as a guess (From 1 to 10) > ");

        scanf("%d",&a); 
                
        warn_the_player(a,b,c); 
        } 
        
        
        
        
        
        while(dif==0)
        {
          printf("Enter the P to play guess game.If you exit the game,enter E.\n");
            scanf("%c",&dec);
             if (dec=='P')
            {
           
           
           
           
           
           
           
    printf("Enter the number as a guess (From 1 to 10) > ");
            
    scanf("%d",&a);   /*First guess number*/
    b=RNG();
            
    warn_the_player(a,b,c);   
    
    for(c=2;a<b || a>b;++c) 
        { 
 
        printf("Try again!!! Enter the number as a guess (From 1 to 10) > ");

        scanf("%d",&a); 
                
        warn_the_player(a,b,c); 
        } 
        
           
           
           
           
           
           
           
            }
            
            if (dec=='E')
            {
            return 0;
            }
        }

    }

    
    while (dec=='E')
    {
    return 0;
    }
    
    
    
    
return 0;

}


    /*------------------------------------------------------------------*/
    /*        This function To generate the random number               */
    /*------------------------------------------------------------------*/

int RNG(){

    int number1;
    srand(time(NULL));
    number1=(rand()%TEN)+ONE;
    return number1;

}

   /*----------------------------------------------------------------------*/
   /*This function calculate difference between input number random number */
   /*----------------------------------------------------------------------*/

int calculate_the_difference(int num1,int num2)
{
    int result, /*difference num1 and num2*/
        temp;  /*temprature value*/
/*To change of value if num2>num1 */ 
    if (num2>num1)
    {
    temp=num2;
    num2=num1;
    num1=temp;
    }
/*-------------------------------*/
  
    result=num1 - num2;

    return result;
}

    /*------------------------------------------------------------------*/
    /*                      This function warns player                  */
    /*------------------------------------------------------------------*/

int warn_the_player (int num_1,int num_2,int i)
{
    int difference; /*To call difference function*/
    
    difference=calculate_the_difference (num_1,num_2);

        /*----------------------------------*/
        /*          If statement            */
        /*----------------------------------*/
  
    if (difference == ZERO)
        printf("<<<Congratulation for winning>>> \n\n");
    else if (difference <= TWO)
        printf("You are close to the number\n");
    else if (difference >= THREE)
        printf("You are far from the number\n");
    else if (difference >= FIVE)
        printf("You are too far from the number\n");       

return difference;

}


int call(int guess,int number,int i)
{


return 0;



}

    /*##################################################################*/
    /*    End of HW02_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c      */
    /*##################################################################*/


