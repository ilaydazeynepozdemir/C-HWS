    /*##################################################################*/
    /*HW03_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*Evaluating the vertical distance of the bouncing ball             */
    /*Inputs:                                                           */
    /*  -first height                                                   */
    /*  -ratio                                                          */
    /*Outputs:                                                          */
    /*  -No                                                             */
    /*  -Rebounching height                                             */
    /*  -Total height                                                   */
    /*##################################################################*/

#include<stdio.h>
#include<stdlib.h>
#define ONE 1
#define ZERO 0
#define FIVE 5
#define TEN 10
#define THIRTY 30

    /*------------------------------------------------------------------*/
    /*                           FUNCTIONS                              */
    /*------------------------------------------------------------------*/

double calculate_the_new_height(double first_height,double ratio,FILE *optr);  /* To calculate rebound height.*/
double calculate_the_vertical_distance(double first_height,double ratio,FILE *optr); /*To calculate all vertical distance .*/
int report(double first_height,double ratio,int count_h,double call,double total,FILE *optr);   /*To print a report */
int report_first(double first_height,double ratio,int count,double temp_first_height,FILE *optr);/*To print first values*/


    /*------------------------------------------------------------------*/
    /*                           MAIN                                   */
    /*------------------------------------------------------------------*/


int 
main (void)
{

    double temp_first_height,first_height,ratio,temp,call=ZERO,total;
    int i=ZERO;/*counter parameter in report function*/

    FILE *optr;
    
    optr=fopen("Result_Table.txt","w");


    srand(time(NULL));
    first_height=(rand()%TEN)+THIRTY;

    srand(time(NULL));
    temp=(rand()%FIVE);
    ratio=(temp/TEN)+0.4; 

    temp_first_height=first_height; /* Do not find first_height */
 
    report_first(first_height,ratio,i,temp_first_height,optr);

    calculate_the_vertical_distance(first_height,ratio,optr) ;  

    fclose(optr);

return 0;

}

/*-----------------------------------------*/
/*this function to calculate rebound height*/
/*-----------------------------------------*/

double calculate_the_new_height(double first_height,double ratio,FILE *optr)
{

    double rebound_height;

    rebound_height = (first_height * ratio) ;

    return rebound_height;

}

/*-----------------------------------------------------------------------*/
/*this function to calculate all vertical distance the ball have traveled*/
/*-----------------------------------------------------------------------*/

double calculate_the_vertical_distance(double first_height,double ratio,FILE *optr) 
{
    double total=ZERO,temp_first_height,count_height,call;
       
    temp_first_height=first_height;
    total=first_height;

  
    call=calculate_the_new_height(first_height,ratio,optr);
    
    for(count_height=ONE; call >= ONE ; count_height++ )
    {
        
        first_height=call;

        total+=first_height+first_height;
        
        report(first_height,ratio,count_height,call,total,optr);

        call=calculate_the_new_height(first_height,ratio,optr);   
    }
    
    report(first_height,ratio,count_height,call,total,optr);

        
    return total;
}


/*----------------------------------------------------*/
/*This function just print first value and first total*/
/*----------------------------------------------------*/

int report_first(double first_height,double ratio,int count,double temp_first_height,FILE *optr)
{


    fprintf(optr,"No - The Rebounching Height -- The Total vertical Distance\n\n" );
    fprintf(optr,"%d         %5.3f                      %5.3f\n\n\n",count+1,temp_first_height,temp_first_height);



    printf("No – The Rebounching Height -- The Total vertical Distance\n\n" );
    printf("%d          %5.3f                       %5.3f\n\n\n",count+1,temp_first_height,temp_first_height);

}


/*----------------------------------*/
/*this function to report for first */
/*----------------------------------*/

int report(double first_height,double ratio,int count_h,double call,double total,FILE *optr)
{
  /*In second printf,first_height = new height.Because it comes into the function*/
    if(call >= ONE)
    {
   
        fprintf(optr,"%d          %5.3f                      %5.3f\n\n\n",count_h+1,first_height,total);
    }
    
    else if(call < ONE)
        fprintf(optr,"The bouncing is stopped and the task completed...\n\n");

    
    
    if(call >= ONE)
    {
   
        printf("%d          %5.3f                      %5.3f\n\n\n",count_h+1,first_height,total);

    }
    else if(call < ONE)
        printf("The bouncing is stopped and the task completed...\n\n");
}


    /*##################################################################*/
    /*    End of HW03_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c      */
    /*##################################################################*/
