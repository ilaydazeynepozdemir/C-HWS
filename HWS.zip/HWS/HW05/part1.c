#include<stdio.h>

typedef enum {PLAY,CRASH,END}object_state;


/*Moves each car according to their speed. Updates output parameters.
Change object1 and object2 to ‘X’ character when the crash happens. Change speed1 and speed2
(inelastic collision) as well. Note that after crash, they will move together and their position and
speed will be same. Do not forget to update game_state variable value when necessary, according
to the situation.*/
void make_move(char *object1, double *position1, double *speed1, int weight1,
char *object2, double *position2, double *speed2, int weight2,object_state *PLAY);



/*Returns crash time as double. When a crash is going to happen, use
the function to determine crash time.*/
double car_crash_time(double position1, double position2, double speed1, double
speed2);


/*Prints road, each car’s location and letter symbols to the console. When
game_state is PLAY show two cars, otherwise just display one so that they have same position value
at CRASH and END states.*/
void print_game_state(char object1, double position1, char object2, double position2,
object_state *game_state);


int
main()
{

char object1,object2;
double position1,position2;

 print_game_state(object1, position1, object2, position2,PLAY);





}



void make_move(char *object1, 
               double *position1, 
               double *speed1, 
               int weight1,
               char *object2, 
               double *position2, 
               double *speed2, 
               int weight2, 
               object_state *PLAY)
               
               
{
   *position1=(*speed1)*(weight1);
   *position2=(*speed2)*(weight2);






}


void print_game_state(char object1, double position1, char object2, double position2, object_state *game_state)
{
   int i,b,c,
       a[50],
       p[50];

 
    for(c=0 ; c<5 ; ++c)
    {
        for(i=0 ; i<50 ; ++i)
        {
            a[i]=(i+1)%10;
        }
    }

    for ( b=0 ; b<50 ; ++b)
        printf("%d",a[b]);
        
printf("\n");   


}
