#include<stdio.h>
#define ARRAY_SIZE 8
#define LINE_LENGTH 30

typedef enum {TRUE=1,FALSE=0}bool;


int max_array(const int myarray[], int n);
int second_max_array(const int myarray[], int n);
int sum_all_array (const int myarray[], int n);
int count_array(const int myarray[], int n, int value);
bool search_array (int myarray[], int n, int value);
void draw_line(void);

int
main(void)
{
    int n=ARRAY_SIZE;
    int myarray[]={16,15,3,3,12,10,1,7,1};
    bool search;
    int max,
        sec_max,
        count,
        sum;

    draw_line();

    max=max_array(myarray, n);
    printf("Maximum array is %d\n",max);
    draw_line();
    
    sec_max=second_max_array(myarray,n);
    printf("Maximum second array is %d\n",sec_max); 
    draw_line();
    
    sum=sum_all_array (myarray, n);
    printf("Sum of all array is %d\n",sum); 
    draw_line();
    
    count=count_array(myarray,n,8);
    printf("Count of value 8 is %d\n",count); 
    
    count=count_array(myarray,n,3);
    printf("Count of value 3 is %d\n",count); 
    
    count=count_array(myarray,n,12);
    printf("Count of value 12 is %d\n",count);  
    draw_line();
   
    search= search_array (myarray, n, 2);
    if(search==FALSE)
        printf("This value is not include in array\n");
    
    search= search_array (myarray, n, 8);
    if(search==FALSE)
        printf("This value is not include in array\n");
        
    search= search_array (myarray, n, 12);
    if(search==FALSE)
        printf("This value is not include in array\n");
    
    draw_line();
        
    return 0;

}

/*Returns maximum value*/
int max_array(const int array[], int n)
{
    int i;/*to process the array elements.Actually i is counter for loop*/
    int max_arr;
    
    max_arr=array[0];  /*to make comparisons between the value*/

    for(i=0 ; i<=n ; ++i)
    {   
        if(max_arr <= array[i]) 
            max_arr=array[i];
    }
    
    return max_arr;
}

/*Returns second maximum value*/
int second_max_array(const int myarray[], int n)
{

    int first_max,
        temp,
        second_max, 
        i=0,a=0,b=1;

    first_max=myarray[a];
    second_max=myarray[b];
    if(second_max==max_array(myarray, n) ){
        second_max=0;
    }
    else if(first_max==max_array(myarray, n) ){
        first_max=0;
    }    

      
    for(b=1;b<=n; ++b)
    {
        if(second_max > first_max)
        {       
            first_max=second_max;
        
        }  
        
    second_max=myarray[b];
    if(second_max==max_array(myarray, n) ){
        second_max=0;
    }

    }
            

    return first_max;
}


/*Returns sum of all array*/
int sum_all_array (int const array[], int n)
{
    int i=0,/*to process the array elements.Actually i is counter for loop*/
        sum=0;
        
    for(i=0 ; i<=n ; ++i)
        sum+=array[i];
    
    return sum;

}

/*Returns count of a value*/
int count_array(int const array[], int n, int value)
{
    int i=0,/*to process the array elements.Actually i is counter for loop*/
        count=0;
   
    while(i<=n)
    {
        while(array[i]==value)
        {   
            count+=1;
            ++i;
            array[i];
        }
    ++i;
    }
  
   return count ;
}


/*Prints location of searched value*/
bool search_array (int array[], int n, int value)
{
    int keep_i=0,/*To keep the value of i*/
        i=FALSE;/*to process the array elements.Actually i is counter for loop*/
    
    for(i=0 ; i<=n  ; ++i)
    {
        if(array[i]!=value)
        {
            ++i;
            if(i==n)
            return FALSE; /*if value is nor include in array*/     
        }
        
        if(array[i]==value)
        {   
            keep_i=i;
            i=n;
            printf("%d is at [%d]\n",value,keep_i);
            return TRUE;
        }
           
     }
 
}



void draw_line(void)
{
    int line;
    for(line=0 ; line<LINE_LENGTH ;++line)
        printf("-");

    printf("\n");

}




