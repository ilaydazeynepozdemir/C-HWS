/*##################################################################*/
/*HW00_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c                 */
/*_____________________________________                             */
/*Written by Ilayda Ozdemir                                         */
/*                                                                  */
/*Description                                                       */
/*___________                                                       */
/*Multication of enter two 2nd degree polynomials                   */
/*Inputs:                                                           */
/*  -Coefficients of the 2nd degree 2 polynomials                   */
/*  -Zero input value of the resulting polynomials                  */
/*Outputs:                                                          */
/*  -Multiplicate 2 polynomials of 2nd degree                       */
/*##################################################################*/
/*                                                                  */ 
/*------------------------------------------------------------------*/
/*                         Includes                                 */
/*------------------------------------------------------------------*/

#include <stdio.h>

int main (void)
{
    double ia0,ia1,ia2; /* coefficients of the input first poly */
    double ia3,ia4,ia5; /* coefficients of the input second poly */
    double ra0,ra1,ra2,ra3,ra4; /* coefficients of the resulting poly */
        
    /* Get the 2nd degree input polynomials */
        
    printf ("Enter the three coefficients of the first polynomial > \n");
    
    scanf("%lf %lf %lf", &ia0,&ia1,&ia2);
    
    
    
    printf ("Enter the three coefficients of the second polynomial > \n");
    
    scanf("%lf %lf %lf", &ia3,&ia4,&ia5);

        
    /* Calculate the resulting coefficients of new poly */
         
    ra0=(ia0*ia3); /* coefficient of x^4 */
    ra1=(ia0*ia4+ia3*ia1); /* coefficient of x^3 */         
    ra2=(ia0*ia5+ia4*ia1+ia2*ia3); /* Coefficient of x^2 */
    ra3=(ia2*ia4+ia5*ia1); /* Coefficient of x */
    ra4=(ia2*ia5); /* Constant number of new poly */
    
    /* Output the resulting poly */
    
    printf("%.1f x^4 + %.1f x^3 + %.1f x^2 + %.1f x + %.1f \n", ra0,ra1,ra2,ra3,ra4);
    return 0;
}


/*##################################################################*/
/*    End of HW00_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c      */
/*##################################################################*/
