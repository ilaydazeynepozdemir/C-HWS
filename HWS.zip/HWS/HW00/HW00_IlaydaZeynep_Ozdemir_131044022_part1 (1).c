/*##################################################################*/
/*HW00_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c                 */
/*_____________________________________                             */
/*Written by Ilayda Ozdemir                                         */
/*                                                                  */
/*Description                                                       */
/*___________                                                       */
/*Takes the integral of given 1st degree polynomial                 */
/*Inputs:                                                           */
/*  -Coefficients of the 1st degree polynomial                      */
/*  -Zero input value of the resulting polynomial                   */
/*Outputs:                                                          */
/*  -Resulting 2nd degree polynomial                                */
/*##################################################################*/
/*                                                                  */
/*------------------------------------------------------------------*/
/*        Includes                                                  */
/*------------------------------------------------------------------*/

#include <stdio.h>
#define HALF 0.5

int main()
{
    double ia0,ia1; /* coefficients of the input poly */
    double p0; /* P(0) value of the resulting poly */
    double ra0,ra1; /* coefficients of the resulting poly */
            
    /* We accept polynomial is (ia0)x + (ia1). */
    /*Integral of this poly : (ia0)(x^2)*HALF + (ia1)x + p0 */
    
    /* Get coefficients of the 1st degree input polynomial */
        
    printf ("Enter the two coefficients of the polynomial ");
    printf ("(from higher to lower order)> \n ");
    
    scanf("%lf %lf", &ia0,&ia1);  /*ia0 is higher input , ia1 is lower input*/
        
    /* Get the zero input polynomial */
        
    printf ("Enter P(0) value for the resulting polynomial> \n ");
    scanf("%lf", &p0);   /*p0 is constant number in resulting of integral*/      
        
    /* Calculate the resulting poly */
        
    ra0=(ia0*HALF) ;  /* The resulting of integral part of x */
    ra1=(ia1) ;  /* The resulting of integral constant number */
   
    /* Output the resulting poly */
    
    printf("The resulting polynomial is %5.3f x^2 + %5.3f x + %5.3f \n", ra0,ra1,p0);
    
    return 0;
       
}

/*##################################################################*/
/*    End of HW00_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c      */
/*##################################################################*/
