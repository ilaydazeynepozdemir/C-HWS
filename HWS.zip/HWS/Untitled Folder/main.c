	/*####################################################*/
	/*HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_test2.c   */
	/*####################################################*/
	/*Written by Ilayda Ozdemir                           */
	/*####################################################*/
	/*Input:                                              */
	/*  -dosya isimlerini alir 		                      */ 
	/*  -binary dosyadan okuyup arrayi doldurur           */  
	/*  -Information of people                            */
	/*Output:                                             */
	/*  -main argumanlarini struct icine doldurur         */
	/*  -mainden alinan dosya isimleri baska 			  */
	/*	dosyaya yazar     			       			      */
	/*  -arrayi xml dosyasina yazdirir        		      */
	/*####################################################*/
#include "part1.h"


int main(int argc, char  *argv[])
{
	
	Working_hours_t hours;
	Files_t files;
	int size;
	Appointment_t *appointments;
    
    get_main_arguments(argc, argv, &hours,  &files);
	print_parameters(&files,  &hours);

	appointments=getRequests(&files,&size);
	write_appointments(appointments, size, &files);

	free(appointments);/*alan fonksiyon icinde olusturuldu*/
	return 0;
}

/*##################################################################*/
/*    End of HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_test2.c      */
/*##################################################################*/