	/*####################################################*/
	/*HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.h   */
	/*_____________________________________               */
	/*Written by Ilayda Ozdemir                           */
	/*####################################################*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*#define DEBUG_PART1*/


#define START_WORK 9
#define END_WORK 17 
#define INPUT_TEXT_FILE "input.txt"
extern const char* records_file_n ;
extern const char* parameters_file_n ;
extern const char* readable_records_file_n ;
extern const char* accepted_appo_file_n ;
extern const char* patients_file_n ;
extern const char* delete_file_n ;


typedef struct{
	int app_id;
	int patient_id;
	int hour;
	
}Appointment_t;

typedef struct 
{
	int start;
	int end;
}Working_hours_t;

typedef struct 
{
	const char* records_file_n;
	const char* patients_file_n;
	const char* delete_file_n;
	const char* readable_records_file_n;
	const char* accepted_appo_file_n;
	const char* parameters_file_n;
	
}Files_t;

/*Dosyadan alip array icine doldurur arrayi return eder*/
extern Appointment_t* getRequests(const Files_t* files, int* size);
/*arraydekileri xml dosyasina yazdirir(xml formatinda)*/
extern void write_appointments(Appointment_t appointments[], int size, const Files_t* files);
/*mainin argumanlarini parcalayip files ve hours icine doldurur*/
extern void get_main_arguments(int argc, char *argv[], Working_hours_t* hours, Files_t* files);
/*doldurdugu structlari text dosyasina yazdirir*/
extern void print_parameters(const Files_t* files, const Working_hours_t* hours);

/*##################################################################*/
/*    End of HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.h      */
/*##################################################################*/