	/*####################################################*/
	/*HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.h   */
	/*_____________________________________               */
	/*Written by Ilayda Ozdemir                           */
	/*####################################################*/

#include "HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.h"
/*#define DEBUG_PART2*/
typedef struct node
{
	int app_id;
	int patient_id;
	char name[50];
	char *history;
	int hour;
	struct node *next;
	
}node_t;

/*linked list'i siralar*/
extern void sort(node_t *head);
/*calisma saatleri arasindaki elemanlari alir*/
/*saatleri ayni olanlar arrayden silinir*/
/*sonra kalan elemanlarla linked list olusturur*/
extern node_t* build_ll(Appointment_t appointmens[], int size, const Working_hours_t* hours);
/*linked list elemanlari csv uzantili dosyaya yazdirilir*/
extern void write_accepted_app(node_t* head, const Files_t* files);
/*okunan xml uzantili dosyadaki <Patient> tag'lerini sayar*/
extern int size_of_patient(const Files_t* files);
/*en uzun history'nin uzunlugunu bulur*/
extern int find_history_length(const Files_t* files);
/*kisilerin eksik bilgilerini tamamlar*/
extern void add_personal_data(node_t* head, const Files_t* files);
/*delete filedaki app_id'lere gore silinmesi gereken randevulari siler*/
extern int delete_appointments(node_t** head, const Files_t* files);
/*linked list icin ayrilan alani geri verir*/
extern void free_list(node_t* head);


/*##################################################################*/
/*    End of HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.h      */
/*##################################################################*/
