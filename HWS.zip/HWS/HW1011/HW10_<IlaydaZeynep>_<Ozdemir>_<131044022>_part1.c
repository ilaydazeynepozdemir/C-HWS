/*####################################################*/
/*HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c   */
/*_____________________________________               */
/*Written by Ilayda Ozdemir                           */
/*####################################################*/
/*getRequests,write_appointments,get_main_arguments,  */
/*print_parameters									  */
/*fonksiyonlarini bulundurur						  */
/*####################################################*/


#include "HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.h"

const char* records_file_n = "Records.bin" ; 
const char* parameters_file_n = "Parameters.txt";
const char* readable_records_file_n ="Records.xml";
const char* accepted_appo_file_n ="Appointments.csv";
const char* patients_file_n = "Patients.xml";
const char* delete_file_n = "Delete.txt";


Appointment_t* getRequests(const Files_t* files, int* size){

	FILE *bin,*inp;
	Appointment_t patient;
	Appointment_t temp[100];
	Appointment_t* arr;  /*appointments arrayini olusturur*/
	int count=0,count2=0,count3=0,status,i=0;
	/**binary***/
	/*BINARY tanimlanirsa input.txt'deki bilgileri binary file'a yazar*/
	#if defined(BINARY)				
	if((inp=fopen(INPUT_TEXT_FILE,"r")) == NULL)
		printf("Check input text file name\n");;
	if((bin=fopen(files->records_file_n,"wb")) == NULL)
		printf("Check records file name\n");;
	do{
		
		status=fscanf(inp,"%d %d %d",&(patient.app_id),&(patient.patient_id),&(patient.hour));
		if(status != EOF){
		printf("binary %d %d %d \n",(patient.app_id),(patient.patient_id),(patient.hour) );
		fwrite(&patient,sizeof(Appointment_t),1,bin);
		 }
    }while(status!=EOF);

    fclose(bin);
    fclose(inp);
    #endif
			/*****************************************************/

   
	if((bin=fopen((files->records_file_n),"rb")) == NULL)
		printf("check records file name\n");;
	i=0;
	while(!feof(bin)){

		fread(&temp[i],sizeof(Appointment_t),1,bin);
		++count;
		++i;
	}

	(*size)=count-1; /*size outputtur. ici dolduruldu*/

	#if defined(DEBUG_PART1)
	printf("\nSIZE = %d\n\n",(*size) );
	#endif

	arr=(Appointment_t*)(malloc((*size)*sizeof(Appointment_t)));	
		
	for(i=0;i<(*size);++i){
		arr[i]=temp[i];
		#if defined(DEBUG_PART1)
		printf("arr %d %d %d \n",arr[i].app_id,arr[i].patient_id,arr[i].hour );
		#endif	
	}
	
	#if defined(DEBUG_PART1)
		printf("\ntemp array\n");
		for(i=0;i<(*size);++i)
		{
			printf("%d %d %d \n",temp[i].app_id,temp[i].patient_id,temp[i].hour );	
		}
	#endif
    
    fclose(bin);
    return arr;

}

void write_appointments(Appointment_t appointments[], int size, const Files_t* files){

	int i;
	FILE *r_inp;
	if((r_inp=fopen(files->readable_records_file_n , "w")) == NULL)
		printf("Check readable records file name\n");
	
	#if defined(DEBUG_PART1)
	for(i=0;i<size;++i){
		printf("*%d %d %d \n", appointments[i].app_id,appointments[i].patient_id,appointments[i].hour );
	}
	#endif

	fprintf(r_inp, "<Size>%d</Size>\n", size);
	fprintf(r_inp, "<Records>\n 	");
	for(i=0;i<size;++i){
		fprintf(r_inp, "<Appointment>\n 		");
		fprintf(r_inp, "<app_id> %d </app_id>\n 		",appointments[i].app_id);
		fprintf(r_inp, "<patient_id> %d </patient_id>\n 		",appointments[i].patient_id);
		fprintf(r_inp, "<hour> %d </hour>\n 	",appointments[i].hour);
		fprintf(r_inp, "</Appointment>\n 	");
	}
	fprintf(r_inp, "</Records>\n");
	/*********************************************/
	fclose(r_inp);
}

void get_main_arguments(int argc, char *argv[], Working_hours_t* hours, Files_t* files){

	char decision;
	int i=1;
	
	(files->records_file_n) = records_file_n ;
	(files->parameters_file_n) = parameters_file_n;
	(files->readable_records_file_n) = readable_records_file_n ;
	(files->accepted_appo_file_n) = accepted_appo_file_n;
	(files->patients_file_n) = patients_file_n;
	(files->delete_file_n) = delete_file_n;
	
	(hours->start) = START_WORK;
	(hours->end) = END_WORK;

	while( (i < argc) ){
			
		#if defined(DEBUG_PART1)
		printf("\n>>>>%d  argv[%d]  %s\n\n",argc,i+1,argv[i+1]);
		#endif
		
		decision=argv[i][1];
		#if defined(DEBUG_PART1)
		printf("decision >> %c\n\n",decision);
		#endif
	
		switch(decision){
			case 'p':
				if(argv[i+1] != NULL)				
					(files->patients_file_n) = argv[i+1];
			break;
			
			case 'r' :
				if(argv[i+1] != NULL)
					(files->records_file_n) = argv[i+1];
			break;

			case 'd':
				if(argv[i+1] != NULL)
					(files->delete_file_n) = argv[i+1];
				
			break;
			
			case 'x':
				if(argv[i+1] != NULL)
					(files->readable_records_file_n) = argv[i+1];
				
			break;
			
			case 'c':
				if(argv[i+1] != NULL)
					(files->accepted_appo_file_n) = argv[i+1];
				
			break;
			
			case 't':
				if(argv[i+1] != NULL)
					(files->parameters_file_n) =argv[i+1];
				
			break;
			
			case 's':
					(hours->start) = atoi(argv[i+1]) ;
			break;
			
			case 'e':
				(hours->end) = atoi(argv[i+1]);
			break;
			}
		i+=2;
	}
}

void print_parameters(const Files_t* files, const Working_hours_t* hours){

	FILE *parameter;

	if((parameter=fopen((files->parameters_file_n),"w"))== NULL){
		printf("Check paramerters file name \n");
		
	}
	
	fprintf(parameter,"%-20s\n", (files->records_file_n));
	fprintf(parameter,"%-20s\n", (files->patients_file_n));
	fprintf(parameter,"%-20s\n", (files->delete_file_n) );
	fprintf(parameter,"%-20s\n", (files->readable_records_file_n) );
	fprintf(parameter,"%-20s\n", (files->accepted_appo_file_n));
	fprintf(parameter,"%-20s\n", (files->parameters_file_n));
	fprintf(parameter,"%-5d\n", (hours->start));
	fprintf(parameter,"%-5d\n", (hours->end));

	#if defined(DEBUG_PART1)
	printf("%-20s\n", (files->records_file_n));
	printf("%-20s\n", (files->patients_file_n));
	printf("%-20s\n", (files->delete_file_n) );
	printf("%-20s\n", (files->readable_records_file_n) );
	printf("%-20s\n", (files->accepted_appo_file_n));
	printf("%-20s\n", (files->parameters_file_n));
	printf("%-5d\n", (hours->start));
	printf("%-5d\n", (hours->end));
	#endif

	fclose(parameter);				

}


/*##################################################################*/
/*    End of HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c      */
/*##################################################################*/
