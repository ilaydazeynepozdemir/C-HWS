	/*####################################################*/
	/*HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c   */
	/*_____________________________________               */
	/*Written by Ilayda Ozdemir                           */
	/*####################################################*/
	/*sort,build_ll,write_accepted_app,size_of_patient	  */
	/*find_history_length,add_personal_data,			  */
	/*delete_appointments,free_list						  */
	/*fonksiyonlarini bulundurur						  */
	/*####################################################*/



#include "part2.h"

void sort(node_t *head){
	node_t *temp1,*temp2,*keep;
	keep = (node_t*)malloc(sizeof(node_t));
	temp1 = (node_t*)malloc(sizeof(node_t));
	temp2 = (node_t*)malloc(sizeof(node_t));

	/*head son eklenen eleman*/
 /*son eklenenle bi onceki eleman karsilastirilir ilk adimda*/
 /*sonra ikiser ikiser karsilastirilarak siralama islemi tamamlanir*/ 
	temp1 = head;
	while(temp1 != NULL)
	{
		temp2 = temp1->next;
	   	while(temp2 != NULL)
	    {
	        if( temp1->hour > temp2->hour){
	        			/*swap*/
	            keep->app_id = temp1->app_id;
	            keep->patient_id = temp1->patient_id;
	            strcpy(keep->name,temp1->name);
	            keep->history = temp1->history;
	            keep->hour = temp1->hour;
	            

	            temp1->app_id = temp2->app_id;
	            temp1->patient_id = temp2->patient_id;
	            strcpy(temp1->name,temp2->name);
	            temp1->history = temp2->history;
	            temp1->hour = temp2->hour;

	            temp2->app_id = keep->app_id;
	            temp2->patient_id = keep->patient_id;
	            strcpy(temp2->name,keep->name);
	            temp2->history = keep->history;
	            temp2->hour = keep->hour;
	      			/*********************/ 

	        }
	        temp2 = temp2->next;
	    }
	    temp1 = temp1->next;
	}
	free(keep);
	free(temp1);
	free(temp2);
}

/*appointments arrayindeki bilgileri linked liste cevirir.*/
/*Baslangic ve bitis saatleri arasindaki degerleri alir*/
/*(baslangic dahil bitis dahil degil)*/
/*siralamadan linked list olusturur*/
/*ardindan sort fonksiyonu cagirilir ve siralanir*/
node_t* build_ll(Appointment_t appointments[], int size, const Working_hours_t* hours){
	node_t *list,*temp;
	int i=0,j=0,k=0;

	list=(node_t*)malloc(sizeof(node_t));
	list=NULL;
		/*saatleri ayni olanlari arrayden cikarttim*/
	for(k=0;k<size;++k){ /*her eleman icin tekrar kontrol ediyor*/
		for(i=0;i<size;++i){
			for(j=i+1;j<size;++j){
				if(appointments[i].patient_id == appointments[j].patient_id || appointments[i].hour == appointments[j].hour){
					appointments[j] = appointments[j+1];


				}
			}
		}
	}
		/*****************************************/
	i=0;
	while(i<size){
		/*calisma saatleri uygun olanlar aliniyor*/
		if(appointments[i].hour >= (hours->start) && appointments[i].hour < (hours->end)){
			temp= (node_t*) malloc(size*sizeof(node_t));
			temp->app_id = appointments[i].app_id;
			temp->patient_id = appointments[i].patient_id;
			temp->hour = appointments[i].hour;
			strcpy(temp->name ,"deneme");
			temp->history = NULL;
			temp->next = NULL;

			if(list == NULL)
				list =temp;	/*ilk dolan tempin adresini tuttum*/
			else{
				temp->next =list; /*ilk dolana ulastim*/
				list = temp;/*diger olusanlari da kaybetmemek icin ona ekledim*/	
			}
		}	
		++i;
	}	
	sort(list);
return list;
}

/*linked listi dosyaya yazar*/
void write_accepted_app(node_t* head, const Files_t* files){
	FILE *accept_app;
	int i=1;
	if((accept_app = fopen(files-> accepted_appo_file_n,"w")) == NULL)
		printf("Check accepted appointments file name\n");
	while(head != NULL){
		fprintf(accept_app,"%d;%d;%d;%s;%s;%d\n",i,head->app_id,head->patient_id,head->name,head->history,head->hour);
		#if defined(DEBUG_PART2)
		printf("%d;%d;%d;%s;%s;%d\n",i,head->app_id,head->patient_id,head->name,head->history,head->hour);
		#endif
		++i;
		head=head->next;
	}
	fclose(accept_app);
}
/*dosyada kac tane hasta bilgisi oldugunu bulmak icin*/
int size_of_patient( const Files_t* files){
	int size_of_pat=0;
	FILE *inp;
	char temp[200];
	char *c;
	if((inp=fopen(files->patients_file_n ,"r")) == NULL )
		printf("Check patients file name %s\n",files->patients_file_n );
	
	do{
		c=fgets(temp,100,inp);
		if(strstr(temp,"<Patient>\n") != NULL)
			++size_of_pat;

	}while(c != 0);
	fclose(inp);
	return size_of_pat;

}

/*en uzun history uzunlugunu bulur*/
/*return eder*/
int find_history_length( const Files_t* files){
	FILE *inp;
	char ch;
	int count_of_history=0,i=0,max=0;
	char temp_add[100];


	if((inp=fopen(files->patients_file_n ,"r")) == NULL )
		printf("Check patients file name %s\n",files->patients_file_n );
	
	fgets(temp_add,100,inp);
	if(strstr(temp_add,"<Records>\n") != NULL){
		do{
		fgets(temp_add,100,inp);
		if(strstr(temp_add,"<Patient>\n") != NULL){
			fgets(temp_add,100,inp);		
			if(strstr(temp_add,"<ID>") != NULL){	
				fgets(temp_add,100,inp);
				if(strstr(temp_add,"<Name>") != NULL){
					count_of_history = 0;
					do{
						fscanf(inp,"%c",&ch);
						++count_of_history;
						if(count_of_history >= max){
							max=count_of_history;
							count_of_history=max;
						}
					}while(ch != '/');
					
					fgets(temp_add,100,inp);
					fgets(temp_add,100,inp);
				}
			}
		}
		++i;
		}while(i<size_of_patient(files));
/*	fgets(temp_add,100,inp);*/
	/*</Records>*/
	}	
	fclose(inp);
	return max;
}


int size_list(node_t* head){
	node_t *keep;
	int count=0;	

	/*linked listin uzunlugunu bulmak icin*/
	keep=head;
	while(keep != NULL){
		++count;
		keep = keep->next;
	}
	#if defined(DEBUG_PART2)
	printf("liste boyu = %d\n",count );
	#endif
	/***********************/
	return count;
}



/*dosyadan bilgiler okur ve uyusan id'ler ile */
/*kisilerin eksik bilgileri tamamlanir*/
/*eksik bilgileri ekler*/
void add_personal_data(node_t* head, const Files_t* files){
	FILE *patient;
	char *token,*temp_historyp;
	char temp_add[200],temp_name[200];
	node_t *keep2;
	int size_of_list=size_list(head);
	int j=0,k=0,i=0;/*donguler icin*/
	int cmp;/*id'leri karsilastirmak icin*/
	int max_length=find_history_length(files);
	int patient_number = size_of_patient(files);

		#if defined(DEBUG_PART2)
		printf("max history length = %d\n",max_length );
		#endif

		#if defined(DEBUG_PART2)
		printf("number of patients in file = %d\n", patient_number );
		#endif
	
	if((patient=fopen(files->patients_file_n ,"r")) == NULL )
		printf("Check patients file name %s\n",files->patients_file_n );	
		


	fgets(temp_add,100,patient);
	/*printf("<Records> %s\n",temp_add );*/
	if(strstr(temp_add,"<Records>\n") != NULL){
		do{
			fgets(temp_add,100,patient);/*<Patient>*/
			/*printf("<Patient> %s\n",temp_add );*/
			if(strstr(temp_add,"<Patient>\n") != NULL){
				fgets(temp_add,100,patient);/*<ID> </ID> satiri*/	
				/*printf("<ID> %s\n",temp_add );*/
				if(strstr(temp_add,"<ID>") != NULL){
					token=strtok(temp_add,">");
					token=strtok(NULL,"<");
					cmp = atoi(token);
					fgets(temp_name,100,patient);/*<Name> </Name> satiri*/
					/*printf("<Name> %s\n", temp_name);*/	
					/**************************************/
					/*********History temp'e dolduruluyor*********/

					temp_historyp=(char*)malloc((max_length+7)*sizeof(char));
					/*+7 kismi </History>'nin "History>" bu kisminin sayisi*/
					temp_historyp[0] = '\0';/*strcat kullanabilmek icin*/
					fgets(temp_add,100,patient);
					while(strstr(temp_add,"</History>") == NULL){ /*</History> yokken*/
						/*printf("TEMP ADD = %s /\n", temp_add);*/
						strcat(temp_historyp,temp_add);	
						fgets(temp_add,100,patient);
						
					}
					strcat(temp_historyp,temp_add);	
					
					fgets(temp_add,100,patient);
					/*printf("</Patient> %s\n", temp_add);*/

					#if defined(DEBUG_PART2)
					printf("TEMP_HISTORYP = %s ----------\n", temp_historyp);
					#endif
					/***************************************/
					
				}
				/*okuyup gecici yerlere dolduruldu*/
				/*eger id'ler uyusursa kisi bilgilerine doldurur*/
				
				keep2=head;

				for(j=0;((j<size_of_list) && (keep2 != NULL));++j){

					if(keep2->patient_id == cmp)
					{		
						keep2->history = (char*)malloc(max_length*sizeof(char));
						if(strstr(temp_name,"<Name>") != NULL){	
							token=strtok(temp_name,">");
							token=strtok(NULL,"<");
							strcpy(keep2->name,token);
						}
						if(strstr(temp_historyp,"<History></History>\n") == NULL){
							token=strtok(temp_historyp,">");
							token=strtok(NULL,"<");
							strcpy(keep2->history,token);
							j=size_of_list; /*bulununca donguden ciksin diye*/
						}
						else if(strstr(temp_historyp,"<History></History>\n") != NULL){
							strcpy(keep2->history,"\0");	/*history bossa*/	
						}
					}
				
					else if(keep2->patient_id != cmp){
						keep2=keep2->next;
					}
					#if defined(DEBUG_PART2)
					if(keep2 == NULL)
						printf("Linked list does not have ID=%d \n",cmp);
					#endif
				}		
			}
			++k;
		}while(k<patient_number); /*<Patient> ile </Patient> arasini */
										  /*Patient sayisi kadar okumasi icin*/
		fgets(temp_add,100,patient);
		/*</Records>*/
		}
	free(temp_historyp);
	/*free(keep2->history);*/
	fclose(patient);
}

/*eger dosyada hic bir sey ya da bulunmayan app_id'si varsa calismiyor*/
/*iptal edilenleri linked listten siler*/
/*iptal edilenlerin app_id'lerini dosyadan okur*/

int delete_appointments(node_t** head, const Files_t* files){
	FILE *del;
	int cmp_app,status;
	node_t* temp_head,*deleted=NULL;
	int count=0;
	
	if((del=fopen(files->delete_file_n,"r")) == NULL)
		printf("Check delete file name\n");
	/*temp_head = (node_t*)malloc(sizeof(node_t));*/ /*BUNA GEREK VAR MI?*/
	
	status=fscanf(del,"%d",&cmp_app);
	if(status == EOF && count==0)
			printf("Delete dosyasi bos\n");
	else 
		while(status != EOF){

			#if defined(DEBUG_PART2)
			printf("\nokunan deger = %d\n\n",cmp_app );
			#endif
				/*ilk degeri silmek icin*/
			if((*head)->app_id == cmp_app){
				(*head)=(*head)->next;
				++count;
			}
			
			temp_head = (*head);
			while((temp_head->next)->next != NULL  && temp_head->next != NULL && temp_head != NULL)  {
				
				if((temp_head->next)->app_id == cmp_app){
					deleted=temp_head->next;
					temp_head->next = (temp_head->next)->next;
					++count;
				}
				
				temp_head = temp_head->next;
				if(temp_head->next == NULL){
					temp_head = deleted;
					/*silinene yonlendiriyoruz*/	
					/*NULL'in next'ine ulasmaya calismasin diye*/		
				}


			}			
				/*sondakini silmek icin*/
			if((temp_head->next)->app_id == cmp_app){
				++count;
				temp_head->next = NULL;
			}	

			status=fscanf(del,"%d",&cmp_app);
			
		}

	#if defined(DEBUG_PART2)
	printf("number of delete appointments = %d \n",count );
	#endif

	fclose(del);
	return count;

}
void free_list(node_t* head){
	node_t *temp;
	do{
		temp = head;
		head=head->next;
		head=head->next;
		free(temp);


	}while(head->next != NULL);
}
/*##################################################################*/
/*    End of HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c      */
/*##################################################################*/