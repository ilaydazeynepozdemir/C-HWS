	/*##########################################################*/
	/*HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_ProduceFile.c   */
	/*##########################################################*/
	/*Written by Ilayda Ozdemir                                 */
	/*##########################################################*/
	/*text dosyasini okuyup binary dosyaya yazar				*/
	/*get_main_arguments fonksiyonu kullanilir.					*/
	/*Yani "part1.h" include edilmeli							*/
	/*##########################################################*/

#include "part1.h"
#define INPUT_TEXT_FILE "input.txt"
int main(int argc, char  *argv[]){
    
    FILE *bin,*inp;
    int status;
    Working_hours_t hours;
	Files_t files;

	Appointment_t patient;
	get_main_arguments(argc, argv, &hours,  &files);
	
	if((inp=fopen(INPUT_TEXT_FILE,"r")) == NULL)
	printf("Check input text file name\n");;
	if((bin=fopen(files.records_file_n,"wb")) == NULL)
		printf("Check records file name\n");;
	do{
		
		status=fscanf(inp,"%d %d %d",&(patient.app_id),&(patient.patient_id),&(patient.hour));
		if(status != EOF){
		printf("binary %d %d %d \n",(patient.app_id),(patient.patient_id),(patient.hour) );
		fwrite(&patient,sizeof(Appointment_t),1,bin);
		 }
    }while(status!=EOF);

    fclose(bin);
    fclose(inp);
    return 0;
}

/*######################################################################*/
/*    End of HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_ProduceFile.c    */
/*######################################################################*/
