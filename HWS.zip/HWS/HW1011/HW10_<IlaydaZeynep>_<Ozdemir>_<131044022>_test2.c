	/*####################################################*/
	/*HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_test2.c   */
	/*_____________________________________               */
	/*Written by Ilayda Ozdemir                           */
	/*Input:                                              */
	/*  -appoinments arrayini alir 	                      */ 
	/*  -dosya isimlerini alir 		                      */ 
	/*  -silinecek app_id'leri alir	                      */ 
	/*  -name ve history bilgilerini alir.                */ 
	/*  -Information of people                            */
	/*Output:                                             */
	/*  -linked list 						              */
	/*  -bilgileri guncellenmis linked list               */
	/*  -silinen eleman sayisi	     			          */
	/*  -silinmis linked list 				              */
	/*####################################################*/
#include "HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.h"

int main(int argc, char  *argv[])
{
	Working_hours_t hours;
	Files_t files;
	int size;
	Appointment_t *appointments;
	node_t *head;
	int number_of_deleted;


    get_main_arguments(argc, argv, &hours,  &files);
	print_parameters(&files, &hours);
	appointments=getRequests(&files,&size);
	/*printf("%d\n",(*size) );*/

	head=build_ll(appointments, size, &hours);

	add_personal_data(head,  &files);

	number_of_deleted=delete_appointments( &(head), &files);

	write_accepted_app(head,&files);

	free_list(head);
	free(appointments);/*alan fonksiyon icinde olusturuldu*/
	return 0;
}
/*##################################################################*/
/*    End of HW10_<IlaydaZeynep>_<Ozdemir>_<131044022>_test2.c      */
/*##################################################################*/
