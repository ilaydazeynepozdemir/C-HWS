typedef struct{
	double real;
	double imag; 
}complex_t;

/*scan complex number with real part and imagine part*/
extern int scan_complex(complex_t *c);
/*print complex number*/
extern void print_complex(complex_t *c);
/*calculate complex number c1 + comlex number c2 */
extern complex_t add_complex(complex_t c1,complex_t c2);
/*calculate complex number c1 - comlex number c2 */
extern complex_t substract_complex(complex_t c1, complex_t c2);
/*calculate complex number c1 * comlex number c2 */
extern complex_t multiply_complex(complex_t c1,complex_t c2);
/*calculate complex number c1 / comlex number c2 */
extern complex_t divide_complex(complex_t c1,complex_t c2);
/*find absolute of complex number*/
extern complex_t abs_complex(complex_t c);

