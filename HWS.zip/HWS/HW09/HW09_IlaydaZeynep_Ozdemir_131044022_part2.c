/*##################################################################*/
/*HW09_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c                 */
/*_____________________________________                             */
/* main kismi                                                       */
/*##################################################################*/

#include <stdio.h>
#include "HW09_IlaydaZeynep_Ozdemir_131044022_complex.h"
int main()
{
	complex_t com1,com2,add,subs,abs,mult,div;
 
 	printf("Enter the real and imaginary parts of a complex number\n");
 	printf("seperated by a space >");   
	scan_complex(&com1);
	printf("Enter a second complex number >");
	scan_complex(&com2);

/*add function*/
	printf("\nadd»»»");
	print_complex(&com1);
	printf("+");
	print_complex(&com2);
	printf("=");
	add=add_complex(com1,com2);
	print_complex(&add);
	printf("\n");

/*substrac function*/
	printf("\nsubstrac»»»");
	print_complex(&com1);
	printf("-");
	print_complex(&com2);
	printf("=");
	subs=substract_complex(com1,com2);
	print_complex(&subs);
	printf("\n");

/*multiply function*/
	printf("\nmultiply»»»");
	print_complex(&com1);
	printf("*");
	print_complex(&com2);
	printf("=");
	mult=multiply_complex(com1,com2);
	print_complex(&mult);
	printf("\n");

/*divide function*/
	printf("\ndivide»»»");
	print_complex(&com1);
	printf("/");
	print_complex(&com2);
	printf("=");
	mult=divide_complex(com1,com2);
	print_complex(&mult);
	printf("\n");

/*absolute function*/
	printf("\nabsolute»»»");
	printf("|");
	print_complex(&com1);
	printf("| =");
	abs=abs_complex(com1);
	print_complex(&abs);
	printf("\n\n");

	return 0;
}

/*  gcc -c part2.c complex.c            */
/*  gcc part2.o complex.o -o part2 -lm  */
/*  /.part2                             */
/*  seklinde compile ve link ettim      */

/*##################################################################*/
/*    End of HW09_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c      */
/*##################################################################*/
