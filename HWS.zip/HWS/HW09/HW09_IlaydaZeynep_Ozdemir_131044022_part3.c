/*##################################################################*/
/*HW09_<IlaydaZeynep>_<Ozdemir>_<131044022>_part3.c                 */
/*_____________________________________                             */
/*Written by Ilayda Ozdemir                                         */
/*Input:                                                            */
/*  -Combination of Positives                                       */
/*  -MPN_index/100ml                                                */
/*  -95% Confidence Limits 	                                        */ 
/*Output:                                                           */
/*  -print the message that result of search                        */
/*##################################################################*/

#include <stdio.h>
#define INPUT_FILE "input3.txt"
#define BINARY_FILE "converted.bin"

typedef struct 
{
	int set1;
	int set2;
	int set3;
	
}triplet_t;

typedef struct 
{
    triplet_t sets;
    int MPN_index;
    int lower;
    int upper;
	
}Row;

void Into_Binary(FILE *text_input, FILE *binary_output);
int Load_Mpn_table(FILE *binary_input_file,Row mpn_table[], int maxsize);
void search( Row mpn_table[], int actual_size, const triplet_t triplet_to_search);

int main()
{

    FILE *inp,*binary;
    Row table[1000];
    int status,i,
    	counter=1;/*dosyanin satir sayisini tutacak */
    			 /*ilk satiri 1 olarak kabul ettim*/	
    int actual_s,total=0;
    char ch;
    triplet_t to_search;
/*--------------------------------------------------*/    
    if((inp=fopen(INPUT_FILE,"r")) == NULL)
    {
    	printf("Error! Check file!!\n");
    	return 1;
    }
    
    /*text dosyasinin satir sayisini bulmak icin*/
    /*aslinda actual size*/
    while(status != EOF)
    {
    	status=fscanf(inp,"%c",&ch);
    		if(ch == '\n')
    			++counter;
    	/*printf("--------%d\n",counter );*/
    }
 	
 	fclose(inp);
/*--------------------------------------------------*/  
 	if((inp=fopen(INPUT_FILE,"r")) == NULL)
    {
    	printf("Error! Check file!!\n");
    	return 1;
    }

    if((binary=fopen(BINARY_FILE,"wb")) == NULL)
    {
    	printf("Error! Check binary file!!\n");
    	return 1;
    } 	
 
 	/*integer bolmesi oldugu icin +1 yaptim*/
 	/*kac kere cagirmasi gerektigini ayarlar*/
    for(i=0; i<((counter/10)+1); ++i)
    {
    	Into_Binary(inp, binary);   
    }

 	fclose(inp);
 	fclose(binary);
/*--------------------------------------------------*/  
 	if((binary=fopen(BINARY_FILE,"rb")) == NULL)
    {
    	printf("Error! Check binary file!!\n");
    	return 1;
    } 
/*search fonksiyonu calissin diye 17 ile cagirdim.	*/
	actual_s = Load_Mpn_table(binary,table,17);

	fclose(binary);
/*--------------------------------------------------*/ 

	printf("Please enter Set1-Set2-Set3 in search for it");
	printf(" in the combination_of_positives components of mpn_table »»»\n");
	scanf("%d%c%d%c%d",&(to_search.set1),&ch,
					  &(to_search.set2),&ch,
					  &(to_search.set3));
   	search(table,actual_s,to_search);

	return 0;
}

/*Text dosyadan okuyup binary dosyaya yazdirma*/
void Into_Binary(FILE *text_input, FILE *binary_output)
{
	Row temp[100];
	char line,space;
	int i=0,status;


	do{
		if(status != EOF ){
			status=fscanf(text_input,"%d %c%c%c%d%c%c%c%d%d%d%d",&(temp[i].sets.set1),&space,&line,&space,
												                 &(temp[i].sets.set2),&space,&line,&space,
												                 &(temp[i].sets.set3),&(temp[i].MPN_index),
										                  		 &(temp[i].lower),&(temp[i].upper));
			                ++i;
			/*son satir iki kere okunuyor*/
		}
		else if(status == EOF)
			i=10;
	}while(i<10);
	fwrite(temp,sizeof(Row),10,binary_output);
}

int Load_Mpn_table(FILE *binary_input_file,Row mpn_table[], int maxsize)
{
	int i,total=0;
	int actual_size=0,sta;
/*bu fonksiyonu yazamadim*/
/*table'in ici dolsun diye bu şekilde ayarlamaya calistim*/	
	sta=fread(mpn_table,sizeof(Row),maxsize,binary_input_file);

return 17;
}

void search( Row mpn_table[], int actual_size, const triplet_t triplet_to_search)
{

	int i;

	for(i=0; i<actual_size ;++i){

		if((triplet_to_search.set1) == (mpn_table[i].sets.set1) &&
		   (triplet_to_search.set2) == (mpn_table[i].sets.set2) &&
		   (triplet_to_search.set3) == (mpn_table[i].sets.set3))
		{
		   	printf("MPN=%d;95 of samples contain between %d and %d bacteria/ml.\n",
		   												(mpn_table[i].MPN_index),
		   												(mpn_table[i].lower),
		   												(mpn_table[i].upper)); 	
		}		
	}
}
/*##################################################################*/
/*    End of HW09_<IlaydaZeynep>_<Ozdemir>_<131044022>_part3.c      */
/*##################################################################*/
