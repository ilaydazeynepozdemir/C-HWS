/*##################################################################*/
/*HW09_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c                 */
/*_____________________________________                             */
/*Written by Ilayda Ozdemir                                         */
/*Input:                                                            */
/*  -Information of workers 	                                    */ 
/*Output:                                                           */
/*  -Update salary                                                  */
/*##################################################################*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define INPUT_FILE "input1.txt"
#define OUTPUT_BIN_FILE "binary_f.bin"

typedef struct 
{
	char *name;
	char *surname;
	char *department;
	char *class1;
	char *class2;
	double salary;
	
}type_I;

typedef struct 
{
	char *name;
	char *surname;
	double salary;
	char degree;
	
}type_E;


typedef union 
{
	type_E ch_e;
	type_I ch_i;
}decide;

typedef struct 
{
	char ch;
	decide dec;

}combine_type;

/*This function to calculate update of salary*/
combine_type salary_rise(combine_type person_info);

/*This function to read information in text file*/
/*and write binary file*/
void read_write(FILE *inp,FILE *outp);

int main(void)
{
	FILE *inp,*outp;

	if((inp=fopen(INPUT_FILE,"r"))==NULL){
	    printf("ERROR!! Check file!\n");
	    return 1;
	}
	outp=fopen(OUTPUT_BIN_FILE,"wb");	

	read_write(inp,outp);

	fclose(inp);
	fclose(outp);
	return 0;
}

/*This function to read information in text file*/
/*and write binary file*/
void read_write(FILE *inp,FILE *outp)
{
	int status;
	char *temp_char_p;
	char *char_p_salary;
	char *char_p_degree;
	char temp[100];
	char* decision;
	combine_type person_info;
/*okuma yaparken department kismindaki Computer Science'i Computer_Science olarak aldim*/	
/*strtok fonksiyonunun kullanimini internetten baktim*/	
/*strtok char* donduruyor*/

    do{    	
    	fgets(temp,500,inp);   	
        decision = strtok(temp," ,"); 
        (person_info.ch)= decision[0];

        if(!feof(inp)){
            if(person_info.ch=='I' || person_info.ch=='i')
			{ 
                (person_info.dec.ch_i.name) = strtok(NULL," ");/*bosluk yerine null*/
                (person_info.dec.ch_i.surname) = strtok(NULL,",");/*virgul yerine null*/
                (person_info.dec.ch_i.department) = strtok(NULL,",");/*virgul yerine null*/
                (person_info.dec.ch_i.class1) = strtok(NULL,",");/*virgul yerine null*/
                (person_info.dec.ch_i.class2) = strtok(NULL,",");/*virgul yerine null*/
                temp_char_p=strtok(NULL,",");
                (person_info.dec.ch_i.salary)=atof(temp_char_p);/*string'i double'a cevirmek icin*/  
                
                person_info=salary_rise(person_info);/*guncellenmis bilgiler*/
				
				fwrite(&person_info,sizeof(combine_type),1,outp);
                
               /* printf("%s %s %s %s %s %.0f\n", (person_info.dec.ch_i.name),(person_info.dec.ch_i.surname),
                 					(person_info.dec.ch_i.department),(person_info.dec.ch_i.class1),
                 					(person_info.dec.ch_i.class2),(person_info.dec.ch_i.salary));*/
            }
			
			else if(person_info.ch=='E' || person_info.ch=='e')
			{
			 	(person_info.dec.ch_e.name) = strtok(NULL," ");/*bosluk yerine null*/
                (person_info.dec.ch_e.surname) = strtok(NULL,",");/*virgul yerine null*/
				temp_char_p= strtok(NULL,",");/*virgul yerine null*/
				(person_info.dec.ch_e.salary)=atof(temp_char_p); /*string' icindeki double'i elde etmek icin*/
				char_p_degree = strtok(NULL," \n");
				(person_info.dec.ch_e.degree) = char_p_degree[0];
				
				person_info=salary_rise(person_info);/*guncellenmis bilgiler*/
				
				fwrite(&person_info,sizeof(combine_type),1,outp);
			 	
              /*  printf("%s %s %.0f %c\n",(person_info.dec.ch_e.name),
								         (person_info.dec.ch_e.surname),
								         (person_info.dec.ch_e.salary),
								         (person_info.dec.ch_e.degree));*/
			}
	    }
        
	}while(!feof(inp));		
}		
/*This function to calculate update of salary*/
combine_type salary_rise(combine_type person_info)
{
	char deg;
    /*Calculate new salary for instructor*/
	if(person_info.ch == 'I' || person_info.ch == 'i'){	
		(person_info.dec.ch_i.salary)=(person_info.dec.ch_i.salary)+
		(((person_info.dec.ch_i.salary)/2)*5)/100 + 
		(((person_info.dec.ch_i.salary)/2)*5.3)/100 ;
	}
	/*Calculate new salary for employee*/
	else if(person_info.ch == 'E' || person_info.ch == 'e'){
			deg=person_info.dec.ch_e.degree;
			switch(deg){
				case 'a':/*Calculate new salary for employee(degree a)*/
					(person_info.dec.ch_e.salary)=(person_info.dec.ch_e.salary)+
								  (((person_info.dec.ch_e.salary)*17.5)/100);
				break;
				case 'b':/*Calculate new salary for employee(degree b)*/
					(person_info.dec.ch_e.salary)=(person_info.dec.ch_e.salary)+
								  (((person_info.dec.ch_e.salary)*12)/100);
				break;
				case 'c':/*Calculate new salary for employee(degree c)*/
					(person_info.dec.ch_e.salary)=(person_info.dec.ch_e.salary)+
								  (((person_info.dec.ch_e.salary)*9)/100);
				break;
			}
	}
return person_info;
}
/*##################################################################*/
/*    End of HW09_<IlaydaZeynep>_<Ozdemir>_<131044022>_part1.c      */
/*##################################################################*/
