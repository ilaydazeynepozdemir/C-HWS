    /*##################################################################*/
    /*HW02_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c                 */
    /*_____________________________________                             */
    /*Written by Ilayda Zeynep Ozdemir                                  */
    /*                                                                  */
    /*Description                                                       */
    /*___________                                                       */
    /*The guess game                                                    */
    /*Inputs:                                                           */
    /*  -Value of midterms and finals                                   */
    /*  -Initials of names and surnames                                 */
    /*Outputs:                                                          */
    /*  -Grades and Contributions                                       */
    /*##################################################################*/


#include <stdio.h>

#define ZERO 0
#define ONE 1.0
#define TWO 2.0
#define THREE 3.0
#define FOUR 4.0
#define TWENTY 20
#define THIRTY 30
#define THIRTY_NINE 39
#define FORTY 40
#define SIXTY_FOUR 64
#define SIXTY_FIVE 65
#define SIXTY_NINE 69
#define SEVENTY 70
#define EIGHTY_FOUR 84
#define EIGHTY_FIVE 85
#define HUNDRED 100

    /*------------------------------------------------------------------*/
    /*                           FUNCTIONS                              */
    /*------------------------------------------------------------------*/


int calculate_point(int exam_1,int exam_2,int f_exam);
int calculate_contribution (int midt1,int midt2,int fin,FILE *optr);
int decide_l_grade(int mid1,int mid2,int fin1,FILE *optr);

    /*------------------------------------------------------------------*/
    /*                           MAIN                                   */
    /*------------------------------------------------------------------*/


int main (void)
{

    FILE *optr,*iptr; /*open input and output file*/
    
    int call1, /*To call point function*/
        mid1_1,mid1_2,mid1_3,mid1_4,mid1_5,/*midterm-1 variable for five student*/
        mid2_1,mid2_2,mid2_3,mid2_4,mid2_5,/*midterm-2 variable for five student*/
        final1,final2,final3,final4,final5;  /*final variable for five student*/

    
    char name1,name2,name3,name4,name5,/*initial of name for five students*/ 
         sname1,sname2,sname3,sname4,sname5; /*initial of surname for five students*/

    optr=fopen("Grades.txt","w");
    iptr=fopen("Students.txt","r");
    
/*-------------------------------------------------------------------*/    
/*                      First Student                                */ 
/*-------------------------------------------------------------------*/ 
   
    fscanf(iptr,"%c %c %d %d %d ",&name1,&sname1,&mid1_1,&mid2_1,&final1);
   
    call1=calculate_point(mid1_1,mid2_1,final1);
    
    fprintf(optr,"%c%c %d ",name1,sname1,call1); 
    
    printf(" %c%c    Point=%d   ",name1,sname1,call1);   

    calculate_contribution (mid1_1,mid2_1,final1,optr);  
/*-------------------------------------------------------------------*/  
/*                                                                   */
/*-------------------------------------------------------------------*/



/*-------------------------------------------------------------------*/    
/*                      Second Student                               */ 
/*-------------------------------------------------------------------*/ 

    fscanf(iptr,"%c %c %d %d %d ",&name2,&sname2,&mid1_2,&mid2_2,&final2);
   
    call1=calculate_point(mid1_2,mid2_2,final2);
    
    fprintf(optr,"%c%c %d ",name2,sname2,call1); 
    
    printf(" %c%c    Point=%d   ",name2,sname2,call1);   

    calculate_contribution (mid1_2,mid2_2,final2,optr); 
/*-------------------------------------------------------------------*/  
/*                                                                   */
/*-------------------------------------------------------------------*/



/*-------------------------------------------------------------------*/    
/*                      Third Student                                */ 
/*-------------------------------------------------------------------*/  

    fscanf(iptr,"%c %c %d %d %d ",&name3,&sname3,&mid1_3,&mid2_3,&final3);
   
    call1=calculate_point(mid1_3,mid2_3,final3);
    
    fprintf(optr,"%c%c %d ",name3,sname3,call1); 
      
    printf(" %c%c    Point=%d   ",name3,sname3,call1);   

    calculate_contribution (mid1_3,mid2_3,final3,optr); 
/*-------------------------------------------------------------------*/  
/*                                                                   */
/*-------------------------------------------------------------------*/



/*-------------------------------------------------------------------*/    
/*                      Fourth Student                               */ 
/*-------------------------------------------------------------------*/ 

    fscanf(iptr,"%c %c %d %d %d ",&name4,&sname4,&mid1_4,&mid2_4,&final4);
   
    call1=calculate_point(mid1_4,mid2_4,final4);
    
    fprintf(optr,"%c%c %d ",name4,sname4,call1); 
       
    printf(" %c%c    Point=%d   ",name4,sname4,call1);   

    calculate_contribution (mid1_4,mid2_4,final4,optr); 
/*-------------------------------------------------------------------*/  
/*                                                                   */
/*-------------------------------------------------------------------*/



/*-------------------------------------------------------------------*/    
/*                      Fifth Student                                */ 
/*-------------------------------------------------------------------*/ 

    fscanf(iptr,"%c %c %d %d %d ",&name5,&sname5,&mid1_5,&mid2_5,&final5);
   
    call1=calculate_point(mid1_5,mid2_5,final5);
    
    fprintf(optr,"%c%c %d ",name5,sname5,call1); 

    printf(" %c%c    Point=%d   ",name5,sname5,call1);   

    calculate_contribution (mid1_5,mid2_5,final5,optr); 
/*-------------------------------------------------------------------*/  
/*                                                                   */
/*-------------------------------------------------------------------*/


 
    fclose(optr);
    fclose(iptr);

    return 0;

}

    /*------------------------------------------------------------------*/
    /*           This function to calculate average point               */
    /*------------------------------------------------------------------*/

int calculate_point(int exam_1,int exam_2,int f_exam)
{
    int result;    
    result=(exam_1*THIRTY)/HUNDRED + (exam_2*THIRTY)/HUNDRED + (f_exam*FORTY)/HUNDRED;

/*Thirty percent of the first and second parameters are taken.*/
   /*Then they are plused forty percent of third parameter*/
    
    
    return result;
}

    /*------------------------------------------------------------------*/
    /*      This function to decide letter grade(A or B or C ...)       */
    /*------------------------------------------------------------------*/

/*optr file is given as a parameter*/
int decide_l_grade(int mid1,int mid2,int fin1,FILE *optr)
{
    
    int grade;
    int call; /*To call point function*/
    
    call=calculate_point(mid1,mid2,fin1);
    
        /*----------------------------------*/
        /*          If statement            */
        /*----------------------------------*/
           
    if ( call >= EIGHTY_FIVE && call <= HUNDRED) 
       grade='A'; 
    else if (call >= SEVENTY && call <= EIGHTY_FOUR)
       grade='B'; 
    else if (call >= SIXTY_FIVE && call <= SIXTY_NINE)
       grade='C'; 
    else if (call >= FORTY && call <= SIXTY_FOUR)
       grade='D';
    else if (call <= THIRTY_NINE && call>= ZERO)
       grade='F'; 

return grade;

}


    /*------------------------------------------------------------------*/
    /*           This function to calculate contribution                */
    /*------------------------------------------------------------------*/

/*optr file is given as a parameter*/
int calculate_contribution(int midt1,int midt2,int fin,FILE *optr)
{

    double contribution;

    char grade; /*call decision function*/
 
           /*Function assign to grade*/
    grade=decide_l_grade(midt1,midt2,fin,optr);         
   
        /*----------------------------------*/
        /*        Switch statement          */
        /*----------------------------------*/
        
    switch (grade)
    {
        
        case 'A': 
                  printf("Letter-grade=%c   ",grade);
                  contribution=FOUR*THREE/TWENTY;
                  printf("Contribution=%.3f \n",contribution);
                  fprintf(optr,"%c %.3f\n",grade,contribution);
        break;
        
        case 'B': 
                  printf("Letter-grade=%c   ",grade);
                  contribution=THREE*THREE/TWENTY;
                  printf("Contribution=%.3f \n",contribution);
                  fprintf(optr,"%c %.3f\n",grade,contribution);
        break;
        
        case 'C': 
                  printf("Letter-grade=%c   ",grade);
                  contribution=TWO*THREE/TWENTY; 
                  printf("Contribution=%.3f \n",contribution);
                  fprintf(optr,"%c %.3f\n",grade,contribution);
        break;
        
        case 'D': 
                  printf("Letter-grade=%c   ",grade);
                  contribution=(ONE*THREE)/TWENTY;
                  printf("Contribution=%.3f \n",contribution);
                  fprintf(optr,"%c %.3f\n",grade,contribution);
        break;
        
        case 'F':
                  printf("Letter-grade=%c   ",grade);
                  contribution=ZERO;
                  printf("Contribution=%.3f \n",contribution);
                  fprintf(optr,"%c %.3f\n",grade,contribution);
        break;

        default: printf("Enter the current number\n");      
    }
    
    return contribution;
}
    /*##################################################################*/
    /*    End of HW02_<IlaydaZeynep>_<Ozdemir>_<131044022>_part2.c      */
    /*##################################################################*/

